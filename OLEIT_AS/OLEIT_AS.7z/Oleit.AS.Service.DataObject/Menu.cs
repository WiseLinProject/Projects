﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Oleit.AS.Service.DataObject
{
    /// <summary>
    /// Menu
    /// </summary>
    [DataContract]
    public class Menu
    {
        [DataMember]
        public int ItemID { set; get; }

        [DataMember]
        public int ParentID { set; get; }

        [DataMember]
        public int Sort { set; get; }

        //[DataMember]
        //public int Level { set; get; }

        [DataMember]
        public string Text { set; get; }

        //[DataMember]
        //public RoleCollection Roles { set; get; }

        [DataMember]
        public string Path { set; get; }

        //[DataMember]
        //public MenuCollection Submenu { set; get; }

        public Menu()
        {
            Text = string.Empty;
            //Roles = new RoleCollection();
            Path = string.Empty;
            //Submenu = new MenuCollection();
        }

        public static Menu DeserializeFromJson(string json)
        {
            return JsonConvert.DeserializeObject<Menu>(json.Trim());
        }

        public string SerializeToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }
    }

    /// <summary>
    /// MenuCollection
    /// </summary>
    public class MenuCollection : List<Menu>
    {
        public MenuCollection()
        {
        }

        public MenuCollection(IEnumerable<Menu> collection)
            : base(collection)
        {
        }

        public MenuCollection(int capacity)
            : base(capacity)
        {
        }

        public static MenuCollection DeserializeFromJson(string json)
        {
            return JsonConvert.DeserializeObject<MenuCollection>(json.Trim());
        }

        public string SerializeToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }
    }
}
