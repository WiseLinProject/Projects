﻿using Oleit.AS.Service.DataObject;
using Oleit.AS.Service.LogicService.RecordAccessReference;
using Oleit.AS.Service.LogicService.TransferAccessReference;
using Oleit.AS.Service.LogicService.TransactionAccessReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;


namespace Oleit.AS.Service.LogicService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "DataEntryService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select DataEntryService.svc or DataEntryService.svc.cs at the Solution Explorer and start debugging.
    public class DataEntryService : IDataEntryService
    {
        public static volatile DataEntryService Instance = new DataEntryService();

        public void DoWork()
        {
        }

        public void UpdateRecord(User user,Record record,JournalCollection jcollection)
        {
            using (RecordAccessClient _recordAccessClient = new RecordAccessClient(EndpointName.RecordAccess))
            {
                _recordAccessClient.Update(user, record, jcollection.ToArray());
            }
        }

        public int InsertRecord(Record record, JournalCollection jcollection)
        {
            using (RecordAccessClient _recordAccessClient = new RecordAccessClient(EndpointName.RecordAccess))
            {
                return _recordAccessClient.Insert(record, jcollection.ToArray());
            }
        }

        public int InsertTransfer(Record record,  Transfer transfer)
        {
            using (TransferAccessClient _transferAccessClient = new TransferAccessClient(EndpointName.TransferAccess))
            {
                return _transferAccessClient.Insert(record, transfer);
            }
        }

        public Record LoadRecord(int recordID)
        {
            using (RecordAccessClient _recordAccessClient = new RecordAccessClient(EndpointName.RecordAccess))
            {
                return _recordAccessClient.QueryByrecordID(recordID)[0];
            }
        }

        public RecordCollection GetRecordList()
        {
            using (RecordAccessClient _recordAccessClient = new RecordAccessClient(EndpointName.RecordAccess))
            {
                return new RecordCollection(_recordAccessClient.QueryAll());
            }
        }

        public void Approve(int recordID)
        {
            using (RecordAccessClient _recordAccessClient = new RecordAccessClient(EndpointName.RecordAccess))
            {
                _recordAccessClient.ChangeStatus(recordID, RecordStatus.Confirm);
            }
        }

        public void Avoid(int recordID)
        {
            using (RecordAccessClient _recordAccessClient = new RecordAccessClient(EndpointName.RecordAccess))
            {
                _recordAccessClient.ChangeStatus(recordID, RecordStatus.Avoid);
            }
        }

        public TransactionCollection LoadTransaction()
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                return new TransactionCollection(_tran.QueryAll());
            }
        }

        public TransactionCollection LoadTransactionByID(int _id)
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                return new TransactionCollection(_tran.QueryByID(_id));
            }
        }

        public TransactionCollection LoadTransactionByPeriodID(int _periodid)
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                return new TransactionCollection(_tran.QueryByPeriodid(_periodid));
            }
        }

        public void InsertTransaction(Transaction _transaction)
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                _tran.InsertTransaction(_transaction);
            }
        }

        public void InsertTransactionCollection(TransactionCollection _collection)
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                _tran.InsertTransactionCollection(_collection.ToArray());
            }
        }

        public void SetNotices(int _id, int _userid)
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                _tran.SetNotices(_id, _userid);
            }
        }

        public void SetConfirm(int _id, int _userid, int _periodid)
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                _tran.SetConfirm(_id, _userid, _periodid);
            }
        }

        public void Updatetransaction(int _id, int _userid, int _fromEntityID, int _toEntityID, decimal _amount)
        {
            using (TransactionAccessClient _tran = new TransactionAccessClient(EndpointName.TransactionAccess))
            {
                _tran.Update(_id, _userid, _fromEntityID, _toEntityID, _amount);
            }
        }

    }
}
