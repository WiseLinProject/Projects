﻿using Oleit.AS.Service.DataObject;
using Oleit.AS.Service.LogicService.EntityAccessReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Oleit.AS.Service.LogicService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EntityService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select EntityService.svc or EntityService.svc.cs at the Solution Explorer and start debugging.
    public class EntityService : IEntityService
    {
        public static volatile EntityService Instance = new EntityService();

        public void DoWork()
        {
        }

        public void NewEntity(Entity entity)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.Insert1(entity);
            }
        }

        public void NewEntity(Entity entity, CashEntity cashEntity)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.Insert2(entity, cashEntity);
            }
        }

        public void NewEntity(Entity entity, Account account)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.Insert3(entity, account);
            }
        }

        private Entity FindParent(EntityCollection entityCollection, int parentID)
        {
            foreach (Entity _entity in entityCollection)
            {
                if (_entity.EntityID == parentID)
                {
                    return _entity;
                }
                else if (_entity.SubEntities.Count == 0)
                {
                    continue;
                }
                else
                {
                    Entity _parent = FindParent(_entity.SubEntities, parentID);

                    if (_parent != null)
                    {
                        return _parent;
                    }
                }
            }

            return null;
        }

        public EntityCollection LoadEntity()
        {
            EntityCollection _entityCollection = new EntityCollection();

            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityCollection = new EntityCollection(_entityAccessClient.Query1());
            }

            int _count = _entityCollection.Count - 1;

            for (int i = _count; i >= 0; i--)
            {
                int _parentID = _entityCollection[i].ParentID;

                if (_parentID == 0)
                {
                    continue;
                }

                Entity _parent = FindParent(_entityCollection, _parentID);
                IEnumerable<Entity> _children = _entityCollection.Where(Entity => (Entity.ParentID == _parentID));

                _parent.SubEntities.AddRange(_children);
                _entityCollection.RemoveAll(Entity => (Entity.ParentID == _parentID));

                i = _entityCollection.Count;
            }

            return _entityCollection;
        }

        public EntityCollection LoadAll()
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new EntityCollection(_entityAccessClient.Query1());
            }
        }

        public Entity FindEntity(int entityID, EntityCollection entityCollection)
        {
            foreach (Entity _entity in entityCollection)
            {
                if (_entity.EntityID == entityID)
                {
                    return _entity;
                }
                else if (_entity.SubEntities.Count == 0)
                {
                    continue;
                }
                else
                {
                    Entity _target = FindEntity(entityID, _entity.SubEntities);

                    if (_target != null)
                    {
                        return _target;
                    }
                }
            }

            return null;
        }

        public EntityCollection LoadEntity(int entityID)
        {
            //using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            //{
            //    return new EntityCollection(_entityAccessClient.Query2(entityID));
            //}

            EntityCollection _entityTree = LoadEntity();

            EntityCollection _result = new EntityCollection();

            Entity _target = FindEntity(entityID, _entityTree);

            if (_target != null)
            {
                _result.Add(_target);
            }

            return _result;
        }

        public EntityCollection LoadEntity(int[] entityIDs)
        {
            EntityCollection _entityCollection = LoadEntity();

            EntityCollection _result = new EntityCollection();

            foreach (int _entityID in entityIDs)
            {
                Entity _target = FindEntity(_entityID, _entityCollection);

                if (_target != null)
                {
                    _result.Add(_target);
                }
            }

            return _result;
        }

        public EntityCollection LoadEntity(string entityName)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new EntityCollection(_entityAccessClient.Query3(entityName));
            }
        }

        private void LoadAccountEntities(EntityCollection source, EntityCollection storage)
        {
            foreach (Entity _entity in source)
            {
                if (_entity.IsAccount == 1)
                {
                    storage.Add(_entity);
                }

                LoadAccountEntities(_entity.SubEntities, storage);
            }
        }

        public EntityCollection LoadAccountEntities(int parentID)
        {
            EntityCollection _entityParent = LoadEntity(parentID);
            EntityCollection _storage = new EntityCollection();

            if (_entityParent.Count == 0)
            {
                return _storage;
            }

            LoadAccountEntities(_entityParent, _storage);

            return _storage;
        }

        public CashEntityCollection LoadCashEntity()
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new CashEntityCollection(_entityAccessClient.QueryCashEntity1());
            }
        }

        public CashEntityCollection LoadCashEntity(int entityID)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new CashEntityCollection(_entityAccessClient.QueryCashEntity2(entityID));
            }
        }

        public CashEntityCollection LoadCashEntity(string contractNumber)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new CashEntityCollection(_entityAccessClient.QueryCashEntity3(contractNumber));
            }
        }

        public AccountCollection LoadAccount()
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new AccountCollection(_entityAccessClient.QueryAccount1());
            }
        }

        public AccountCollection LoadAccount(int entityID)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new AccountCollection(_entityAccessClient.QueryAccount2(entityID));
            }
        }

        public AccountCollection LoadAccount(string accountName)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new AccountCollection(_entityAccessClient.QueryAccount3(accountName));
            }
        }

        public EntityCollection LoadSubtotalEntity()
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new EntityCollection(_entityAccessClient.QuerySumEntity1(SumType.Subtotal));
            }
        }

        public EntityCollection LoadSubtotalEntity(int entityID)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new EntityCollection(_entityAccessClient.QuerySumEntity2(entityID, SumType.Subtotal));
            }
        }

        public EntityCollection LoadTransactionEntity()
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new EntityCollection(_entityAccessClient.QuerySumEntity1(SumType.Transaction));
            }
        }

        public EntityCollection LoadTransactionEntity(int entityID)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new EntityCollection(_entityAccessClient.QuerySumEntity2(entityID, SumType.Transaction));
            }
        }

        public void SaveEntity(Entity entity)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.Update1(entity);
            }
        }

        public void SaveEntity(Entity entity, CashEntity cashEntity)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.Update2(entity, cashEntity);
            }
        }

        public void SaveEntity(int userID, Entity entity, Account account)
        {
            AccountCollection _accountCollection = LoadAccount(entity.EntityID);

            if (_accountCollection.Count == 0)
            {
                using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
                {
                    account.EntityID = entity.EntityID;

                    _entityAccessClient.Insert4(account);
                    SaveEntity(entity);
                }
            }
            else
            {
                using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
                {
                    _entityAccessClient.Update3(userID, entity, account);
                }
            }
        }

        private void ChangeEntityType(EntityCollection entityCollection, EntityType type)
        {
            if (type != EntityType.BadDebt)
            {
                throw new NotSupportedException("if (type != EntityType.BadDebt)");
            }

            foreach (Entity _entity in entityCollection)
            {
                ChangeEntityType(_entity.SubEntities, type);

                _entity.EntityType = type;

                SaveEntity(_entity);
            }
        }

        public void ChangeEntityType(int entityID, EntityType type)
        {
            if (type != EntityType.BadDebt)
            {
                throw new NotSupportedException("if (type != EntityType.BadDebt)");
            }

            Entity _entity = LoadEntity(entityID)[0];

            _entity.EntityType = type;

            SaveEntity(_entity);

            ChangeEntityType(_entity.SubEntities, type);
        }

        public void NewRelation(int entityID, int targetEntityID, Relation relation)
        {
            Entity _entity = null;
            Entity _parentEntity = null;
            Entity _targetEntity = null;
            string _entityName = "";

            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entity = new EntityCollection(_entityAccessClient.Query2(entityID))[0];
                _parentEntity = new EntityCollection(_entityAccessClient.Query2(_entity.ParentID))[0];
                _targetEntity = new EntityCollection(_entityAccessClient.Query2(targetEntityID))[0];
            }

            if ((relation.Description != RelationDescription.Allocate) && (relation.Description != RelationDescription.Position))
            {
                relation.TargetEntity = _targetEntity;
                relation.Entity = _entity;

                using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
                {
                    _entityAccessClient.SetRelateEntity(relation);
                }

                return;
            }

            Account _oriAccount = LoadAccount(entityID)[0];

            Entity _node = new Entity()
            {
                ParentID = _targetEntity.EntityID,
                Enable = 1,
                EntityName = _parentEntity.EntityName,
                EntityType = _targetEntity.EntityType,
                Currency = new Currency() { CurrencyID = _targetEntity.Currency.CurrencyID },
                ExchangeRate = _targetEntity.ExchangeRate,
            };

            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _node.EntityID = _entityAccessClient.Insert1(_node);
            }

            if (_node.EntityID <= 0)
            {
                throw new MethodAccessException("if (_node.EntityID <= 0)");
            }
            if (relation.Description == RelationDescription.Allocate)
                _entityName = string.Format("{0}", _targetEntity.EntityName);
            else if (relation.Description == RelationDescription.Position)
                _entityName = string.Format("Position of {0}", _targetEntity.EntityName);
            else if (relation.Description == RelationDescription.Position)
                _entityName = string.Format("{0} Comm", _targetEntity.EntityName);
            else
            {
                _entityName = string.Format("{0}", _targetEntity.EntityName);
            }


            Entity _accountEntity = new Entity()
            {
                ParentID = _node.EntityID,
                IsLastLevel = 1,
                IsAccount = 1,
                Enable = 1,
                EntityName = _entityName,
                EntityType = _targetEntity.EntityType,
                Currency = new Currency() { CurrencyID = _targetEntity.Currency.CurrencyID },
                ExchangeRate = _targetEntity.ExchangeRate,
            };

            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _accountEntity.EntityID = _entityAccessClient.Insert1(_accountEntity);
            }

            if (_accountEntity.EntityID <= 0)
            {
                throw new MethodAccessException("if (_accountEntity.EntityID <= 0)");
            }

            Account _newAccount = new Account()
            {
                EntityID = _accountEntity.EntityID,
                Company = _oriAccount.Company,
                AccountName = _oriAccount.AccountName,
                Password = _oriAccount.Password,
                AccountType = _oriAccount.AccountType,
                BettingLimit = _oriAccount.BettingLimit,
                Status = _oriAccount.Status,
            };

            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.Insert4(_newAccount);
            }

            relation.TargetEntity = _accountEntity;
            relation.Entity = _entity;

            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.SetRelateEntity(relation);
            }
        }

        public void SetRelation(int entityID, Relation relation)
        {
            //EntityCollection _entityCollection = LoadEntity2(entityID);

            //foreach (Entity _entity in _entityCollection)
            //{
            //    Relation _relation = _entity.RelationCollection.FirstOrDefault(Relation => (Relation.TargetEntity == relation.TargetEntity));

            //    if (_relation == null)
            //    {
            //        _entity.RelationCollection.Add(_relation);
            //    }
            //    else
            //    {
            //        _relation.Numeric = relation.Numeric;
            //    }
            //    using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            //    {
            //        _entityAccessClient.SetRelateEntity(_relation);
            //    }
            //}
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.SetRelateEntity(relation);
            }
        }

        public void SetCurrencyAndRate(int entityID, string currencyID, decimal rate)
        {//OK
            //EntityCollection _entityCollection = LoadEntity2(entityID);

            //foreach (Entity _entity in _entityCollection)
            //{
            //    _entity.Currency.CurrencyID = currencyID;
            //    _entity.ExchangeRate = rate;

            //    SaveEntity(_entity);
            //}
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                Currency _currency = new Currency();
                _currency.CurrencyID = currencyID;
                _entityAccessClient.SetRate(entityID, rate, _currency);
            }
        }

        public RelationCollection GetRelateEntity(int entityID)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                return new RelationCollection(_entityAccessClient.GetRelateEntity(entityID));
            }
        }


        public void ChangeRate(int entityID, decimal rate)
        {
            EntityCollection _entityCollection = LoadEntity(entityID);

            foreach (Entity _entity in _entityCollection)
            {
                _entity.ExchangeRate = rate;

                SaveEntity(_entity);
            }
        }

        public void ChangeStatus(User user,int entityID,Status status)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                _entityAccessClient.ChangeStatus(user, entityID, status);
            }
        }

        public EntityCollection GetEntryEntities(string userName)
        {
            //throw new NotImplementedException(); //TODO:
            return new EntityCollection();
        }

        private void DisableOrEnable(EntityCollection entityCollection, int enable)
        {
            foreach (Entity _entity in entityCollection)
            {
                DisableOrEnable(_entity.SubEntities, enable);

                using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
                {
                    if (enable == 0)
                    {
                        _entityAccessClient.Disable(_entity.EntityID);
                    }
                    else if (enable == 1)
                    {
                        _entityAccessClient.Enable(_entity.EntityID);
                    }
                }
            }
        }

        public void Disable(int entityID)
        {
            DisableOrEnable(LoadEntity(entityID), 0);
        }

        public void Enable(int entityID)
        {
            DisableOrEnable(LoadEntity(entityID), 1);
        }

        public RelationCollection RelationEntity(int _entityID)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {
                //First Get Relation Table
                RelationCollection _recollection = new RelationCollection(_entityAccessClient.GetRelateEntity(_entityID));                
                foreach (Relation _re in _recollection)
                {
                    if (_re.Description.Equals(RelationDescription.Allocate) || _re.Description.Equals(RelationDescription.Position))
                    {
                        _re.Entity = new EntityCollection(_entityAccessClient.QueryRelation(_re.TargetEntity.EntityID))[0];
                    }
                }
                return _recollection;
            }
        }

        public RelationCollection RelationEntityWandL(int _entityID)
        {
            using (EntityAccessClient _entityAccessClient = new EntityAccessClient(EndpointName.EntityAccess))
            {       
                RelationCollection _recollection = new RelationCollection(_entityAccessClient.GetRelateEntityWandL(_entityID));                
                return _recollection;
            }
        }

    }
}
