﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Oleit.AS.Service.DataObject;
using Oleit.AS.Service.LogicService.MLJRecordAccessReference;



namespace Oleit.AS.Service.LogicService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MLJService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MLJService.svc or MLJService.svc.cs at the Solution Explorer and start debugging.
    public class MLJService : IMLJService
    {
        public void CheckAndAdd(int PeriodID,int userID)
        {
            using (MLJRecordAccessClient _MLJAccessClient = new MLJRecordAccessClient(EndpointName.MLJRecordAccess))
            {
                _MLJAccessClient.CheckAndAdd(PeriodID, userID);
            }
        }

        public MLJJournalCollection Query(int PeriodID, string EntityName)
        {
           using (MLJRecordAccessClient _MLJAccessClient = new MLJRecordAccessClient(EndpointName.MLJRecordAccess))
            {               
               return new MLJJournalCollection(_MLJAccessClient.QueryByPeriodIDEntityName(PeriodID,EntityName));
            }
        }

        public void UpdateJournal(MLJJournal journal)
        {
            using (MLJRecordAccessClient _MLJAccessClient = new MLJRecordAccessClient(EndpointName.MLJRecordAccess))
            {
                _MLJAccessClient.UpdateJournal(journal);
            }
        }

        public void Approve(int MLJRecordID)
        {            
            using (MLJRecordAccessClient _MLJAccessClient = new MLJRecordAccessClient(EndpointName.MLJRecordAccess))
            {
               //First get all JournalCollection in this period
            //    MLJRecord _MLJ = new MLJRecord(_MLJAccessClient.(MLJRecordID));
             //  MLJJournalCollection _MLJjournalCollection = new MLJJournalCollection(_MLJAccessClient.QueryJournalByRecordID(MLJRecordID));
               //insert Record
            }
        }

    }
}
