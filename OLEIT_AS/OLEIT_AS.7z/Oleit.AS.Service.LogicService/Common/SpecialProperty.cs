﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Oleit.AS.Service.LogicService
{
    public class SpecialProperty
    {
        /// <summary>
        /// ExchangeDiff
        /// </summary>
        public const string ExchangeDiff = "ExchangeDiff";

        /// <summary>
        /// ClosedPeriod
        /// </summary>
        public const string ClosedPeriod = "ClosedPeriod";
    }
}