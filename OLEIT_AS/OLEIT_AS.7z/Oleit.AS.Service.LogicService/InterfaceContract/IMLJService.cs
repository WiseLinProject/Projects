﻿using Oleit.AS.Service.DataObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Web;

namespace Oleit.AS.Service.LogicService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IMLJService" in both code and config file together.
    [ServiceContract]
    public interface IMLJService
    {
        [OperationContract]
        void CheckAndAdd(int PeriodID, int userID);

        [OperationContract]
        MLJJournalCollection Query(int PeriodID, string EntityName);





    }
}
