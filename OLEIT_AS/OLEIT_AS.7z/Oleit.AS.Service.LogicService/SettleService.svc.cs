﻿using Oleit.AS.Service.DataObject;
using Oleit.AS.Service.LogicService.PropertyAccessReference;
using Oleit.AS.Service.LogicService.RecordAccessReference;
using Oleit.AS.Service.LogicService.PeriodAccessReference;
using Oleit.AS.Service.LogicService.WeeklySummaryReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Transactions;

namespace Oleit.AS.Service.LogicService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "SettleService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select SettleService.svc or SettleService.svc.cs at the Solution Explorer and start debugging.
    public class SettleService : ISettleService
    {
        public static volatile SettleService Instance = new SettleService();

        public void DoWork()
        {
        }

        public void WeeklySummarize(Entity entity)
        {
            throw new NotImplementedException();
        }

        public void WinLossConfirm(WeeklySummaryCollection weeklySummaryCollection, int recordID)
        {
            foreach (WeeklySummary _week in weeklySummaryCollection)
            {
                using (WeeklySummaryAccessClient _weekAccessClient = new WeeklySummaryAccessClient(EndpointName.WeeklySummaryAccess))
                {
                    //Get this Period WeeklySummary
                    WeeklySummaryCollection _thisweek = new WeeklySummaryCollection(_weekAccessClient.Query(_week.Period.ID, _week.Entity.EntityID));
                    if (_thisweek.Count > 0)
                    {                        
                        decimal _basepre=0;
                        decimal _basewl = 0;
                        decimal _basetransfer = 0;
                        decimal _basebalance = 0;
                        decimal _basetran = 0;

                        decimal _sgdpre = 0;
                        decimal _sgdwl = 0;
                        decimal _sgdtransfer = 0;
                        decimal _sgdbalance = 0;
                        decimal _sgdtran = 0;

                        if(!_thisweek[0].BasePrevBalance.Equals("")) 
                            _basepre = _thisweek[0].BasePrevBalance;
                        if(!_thisweek[0].BaseTransfer.Equals(""))
                            _basetransfer = _thisweek[0].BaseTransfer;
                        if(!_week.BaseWinAndLoss.Equals(""))         
                            _basewl = _week.BaseWinAndLoss;
                        if (!_week.BaseTransaction.Equals(""))
                            _basetran = _thisweek[0].BaseTransaction;

                        _basebalance = _basepre + _basetransfer + _basewl + _basetran;

                        if (!_thisweek[0].SGDPrevBalance.Equals(""))
                            _sgdpre = _thisweek[0].SGDPrevBalance;
                        if (!_thisweek[0].SGDTransfer.Equals(""))
                            _sgdtransfer = _thisweek[0].SGDTransfer;
                        if (!_week.SGDWinAndLoss.Equals(""))
                            _sgdwl = _week.SGDWinAndLoss;
                        if (!_thisweek[0].SGDTransaction.Equals(""))
                            _sgdtran = _thisweek[0].SGDTransaction;

                        _sgdbalance = _sgdpre + _sgdtransfer + _sgdwl + _sgdtran;

                        //_week.BasePrevBalance = _thisweek[0].BasePrevBalance;
                        //_week.SGDPrevBalance = _thisweek[0].SGDPrevBalance;
                        //_week.BaseTransfer = _thisweek[0].BaseTransfer;
                        _thisweek[0].BaseWinAndLoss = _week.BaseWinAndLoss;
                        _thisweek[0].SGDWinAndLoss = _week.SGDWinAndLoss;

                       // _week.SGDTransfer = 
                        _thisweek[0].BaseCurrency = _week.BaseCurrency;
                        _thisweek[0].ExchangeRate = _week.ExchangeRate;
                        _thisweek[0].BaseWinAndLoss = _week.BaseWinAndLoss;
                        _thisweek[0].SGDWinAndLoss = _week.SGDWinAndLoss;
                        _thisweek[0].BaseBalance = _basebalance;
                        _thisweek[0].SGDBalance = _sgdbalance;
                        _thisweek[0].ConfirmUser = _week.ConfirmUser;
                        _thisweek[0].Status = WeeklySummaryStatus.None;
                        _weekAccessClient.Update1(_thisweek[0]);
                    }
                    else
                    {
                        WeeklySummary _newweek = new WeeklySummary();
                        _newweek.Period.ID = _week.Period.ID;
                        _newweek.Entity = _week.Entity;
                        _newweek.BaseCurrency = _week.BaseCurrency;
                        _newweek.ExchangeRate = _week.ExchangeRate;
                        _newweek.BasePrevBalance = _week.BaseBalance;
                        _newweek.SGDPrevBalance = _week.SGDBalance;
                        _newweek.BaseWinAndLoss = 0;
                        _newweek.SGDWinAndLoss = 0;
                        _newweek.BaseTransfer = 0;
                        _newweek.SGDTransfer = 0;
                        _newweek.BaseTransaction = 0;
                        _newweek.SGDTransaction = 0;
                        _newweek.BaseBalance = 0;
                        _newweek.SGDBalance = 0;
                        _newweek.Status = WeeklySummaryStatus.None;
                        _newweek.BasePrevTransaction = _week.BaseTransaction;
                        _newweek.SGDPrevTransaction = _week.SGDTransaction;
                        _newweek.ConfirmUser = new User();
                        _weekAccessClient.Insert1(_newweek);
                    }
                }
                using (RecordAccessClient _recordclient = new RecordAccessClient(EndpointName.RecordAccess))
                {
                    _recordclient.ChangeStatus(recordID, RecordStatus.Confirm);
                }
            }
        
        }

        public void TransferConfirm(WeeklySummaryCollection weeklySummaryCollection,int recordID)
        {
            foreach (WeeklySummary _week in weeklySummaryCollection)
            {
                using (WeeklySummaryAccessClient _weekAccessClient = new WeeklySummaryAccessClient(EndpointName.WeeklySummaryAccess))
                {
                    //Get this Period WeeklySummary
                    WeeklySummaryCollection _thisweek = new WeeklySummaryCollection(_weekAccessClient.Query(_week.Period.ID, _week.Entity.EntityID));
                    if (_thisweek.Count > 0)
                    {                        
                        decimal _basepre=0;
                        decimal _basewl = 0;
                        decimal _basetransfer = 0;
                        decimal _basebalance = 0;
                        decimal _basetran = 0;

                        decimal _sgdpre = 0;
                        decimal _sgdwl = 0;
                        decimal _sgdtransfer = 0;
                        decimal _sgdbalance = 0;
                        decimal _sgdtran = 0;

                        if(!_thisweek[0].BasePrevBalance.Equals("")) 
                            _basepre = _thisweek[0].BasePrevBalance;
                        if(!_thisweek[0].BaseTransfer.Equals(""))
                            _basetransfer = _week.BaseTransfer;
                        if(!_week.BaseWinAndLoss.Equals(""))
                            _basewl = _thisweek[0].BaseWinAndLoss;
                        if (!_week.BaseTransaction.Equals(""))
                            _basetran = _thisweek[0].BaseTransaction;

                        _basebalance = _basepre + _basetransfer + _basewl + _basetran;

                        if (!_thisweek[0].SGDPrevBalance.Equals(""))
                            _sgdpre = _thisweek[0].SGDPrevBalance;
                        if (!_thisweek[0].SGDTransfer.Equals(""))
                            _sgdtransfer = _week.SGDTransfer;
                        if (!_week.SGDWinAndLoss.Equals(""))
                            _sgdwl = _thisweek[0].SGDWinAndLoss;
                        if (!_thisweek[0].SGDTransaction.Equals(""))
                            _sgdtran = _thisweek[0].SGDTransaction;

                        _sgdbalance = _sgdpre + _sgdtransfer + _sgdwl + _sgdtran;

                      //  _thisweek[0].BasePrevBalance = _thisweek[0].BasePrevBalance;
                        _thisweek[0].SGDTransfer = _week.SGDTransfer;
                        _thisweek[0].BaseTransfer = _week.BaseTransfer;

                       // _week.SGDTransfer = 
                        _thisweek[0].BaseCurrency = _week.BaseCurrency;
                        _thisweek[0].ExchangeRate = _week.ExchangeRate;
                        _thisweek[0].BaseWinAndLoss = _week.BaseWinAndLoss;
                        _thisweek[0].SGDWinAndLoss = _week.SGDWinAndLoss;
                        _thisweek[0].BaseBalance = _basebalance;
                        _thisweek[0].SGDBalance = _sgdbalance;
                        _thisweek[0].ConfirmUser = _week.ConfirmUser;
                        _thisweek[0].Status = WeeklySummaryStatus.None;
                        _weekAccessClient.Update1(_thisweek[0]);
                    }
                    else
                    {
                        WeeklySummary _newweek = new WeeklySummary();
                        _newweek.Period.ID = _week.Period.ID;
                        _newweek.Entity = _week.Entity;
                        _newweek.BaseCurrency = _week.BaseCurrency;
                        _newweek.ExchangeRate = _week.ExchangeRate;
                        _newweek.BasePrevBalance = _week.BaseBalance;
                        _newweek.SGDPrevBalance = _week.SGDBalance;
                        _newweek.BaseWinAndLoss = 0;
                        _newweek.SGDWinAndLoss = 0;
                        _newweek.BaseTransfer = 0;
                        _newweek.SGDTransfer = 0;
                        _newweek.BaseTransaction = 0;
                        _newweek.SGDTransaction = 0;
                        _newweek.BaseBalance = 0;
                        _newweek.SGDBalance = 0;
                        _newweek.Status = WeeklySummaryStatus.None;
                        _newweek.BasePrevTransaction = _week.BaseTransaction;
                        _newweek.SGDPrevTransaction = _week.SGDTransaction;
                        _newweek.ConfirmUser = new User();
                        _weekAccessClient.Insert1(_newweek);
                    }
                }
                using (RecordAccessClient _recordclient = new RecordAccessClient(EndpointName.RecordAccess))
                {
                    _recordclient.ChangeStatus(recordID, RecordStatus.Confirm);
                }
            }
        }

        public void TransferPL(Period period)
        {
            using (RecordAccessClient _recordAccessClient = new RecordAccessClient(EndpointName.RecordAccess))
            {
                _recordAccessClient.QueryByperiod(period);               
            }
        }

        public bool CloseEntry()
        {
            //First: get this period SummaryCollection
            int _periodid = 0;
            Period _nextperiod = new Period();
           
                using (PeriodAccessClient _periodAccessClient = new PeriodAccessClient(EndpointName.PeriodAccess))
                {
                    Period _close = PeriodService.Instance.GetClosedPeriod()[0];
                    _periodid = _close.ID;
                    _nextperiod = new PeriodCollection(_periodAccessClient.Query4(_close.PeriodNo, 1))[0];                 
                }
                using (WeeklySummaryAccessClient _weekAccessClient = new WeeklySummaryAccessClient(EndpointName.WeeklySummaryAccess))
                {
                    WeeklySummaryCollection _weekCollection = new WeeklySummaryCollection(_weekAccessClient.QuerybyPeriod(_periodid));
                    if (!_periodid.Equals(0))
                    {
                        foreach (WeeklySummary _week in _weekCollection)
                        {
                            if (_week.Status.Equals(WeeklySummaryStatus.None))
                                return false;
                            //Second: Add Next Period Summary
                            WeeklySummary _newweek = new WeeklySummary();
                            _newweek.Period.ID = _nextperiod.ID;
                            _newweek.Entity = _week.Entity;
                            _newweek.BaseCurrency = _week.BaseCurrency;
                            _newweek.ExchangeRate = _week.ExchangeRate;
                            _newweek.BasePrevBalance = _week.BaseBalance;
                            _newweek.SGDPrevBalance = _week.SGDBalance;
                            //_newweek.BaseWinAndLoss = 0;
                            //_newweek.SGDWinAndLoss = 0;
                            //_newweek.BaseTransfer = 0;
                            //_newweek.SGDTransfer = 0;
                            //_newweek.BaseTransaction = 0;
                            //_newweek.SGDTransaction = 0;
                            //_newweek.BaseBalance = 0;
                            //_newweek.SGDBalance = 0;
                            //_newweek.Status = WeeklySummaryStatus.None;
                            _newweek.BasePrevTransaction = _week.BaseTransaction;
                            _newweek.SGDPrevTransaction = _week.SGDTransaction;
                            _weekAccessClient.Insert1(_newweek);
                        }
                    }
                }
                //Third: Change Property Table ColsedPeriod value
                Property _pro = new Property();
                _pro.PropertyValue = _nextperiod.PeriodNo;
                _pro.PropertyName = "ClosedPeriod";
                PropertiesService.Instance.SetProperty("ClosedPeriod", _pro);
                
                return true;
           
        }

        public void ReverseClosing()
        {
            //First: get this periodid

            string _preperiod = "";
            Period _close = PeriodService.Instance.GetClosedPeriod()[0];
            using (PeriodAccessClient _periodAccessClient = new PeriodAccessClient(EndpointName.PeriodAccess))
            {
                _preperiod = new PeriodCollection(_periodAccessClient.Query4(_close.PeriodNo, -1))[0].PeriodNo;
            }
            Property _pro = new Property();
            _pro.PropertyValue = _preperiod;
            _pro.PropertyName = "ClosedPeriod";
            PropertiesService.Instance.SetProperty("ClosedPeriod", _pro);
        }
    }
}
