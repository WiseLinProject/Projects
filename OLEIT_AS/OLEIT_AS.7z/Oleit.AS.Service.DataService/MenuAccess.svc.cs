﻿using Oleit.AS.Service.DataObject;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;


namespace Oleit.AS.Service.DataService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MenuAccess" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MenuAccess.svc or MenuAccess.svc.cs at the Solution Explorer and start debugging.
    public class MenuAccess : IMenuAccess
    {
        string connectionString = ConfigurationManager.ConnectionStrings["AccountDataBase"].ConnectionString;
        public void Insert(Role role, Menu menu)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@Menu_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = menu.ItemID;
                SqlParameter ColumnParam1 = command.Parameters.Add("@Role_ID", System.Data.SqlDbType.Int);
                ColumnParam1.Value = role.ID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void Insert(Role role, MenuCollection menucollection)
        {
            foreach (Menu menu in menucollection)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SP_Frank_TEST";

                    SqlParameter ColumnParam = command.Parameters.Add("@Menu_ID", System.Data.SqlDbType.Int);
                    ColumnParam.Value = menu.ItemID;
                    SqlParameter ColumnParam1 = command.Parameters.Add("@Role_ID", System.Data.SqlDbType.Int);
                    ColumnParam1.Value = role.ID;
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public MenuCollection Query(Role role)
        {
            MenuCollection collection = new MenuCollection();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@Role_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = role.ID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Menu menu = new Menu();
                        menu.ItemID = Convert.ToInt32(reader["Menu_ID"]);
                        menu.Text = reader["Text"].ToString();
                        menu.Path = reader["Path"].ToString();
                        menu.ParentID = Convert.ToInt32(reader["ParentID"]);
                        menu.Sort = Convert.ToInt32(reader["Sort"]);
                        collection.Add(menu);
                    }
                }
                return collection;
            }
            
        }

        public MenuCollection Query()
        {
            MenuCollection collection = new MenuCollection();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Menu menu = new Menu();
                        menu.ItemID = Convert.ToInt32(reader["Menu_ID"]);
                        menu.Text = reader["Text"].ToString();
                        menu.Path = reader["Path"].ToString();
                        menu.ParentID = Convert.ToInt32(reader["ParentID"]);
                        menu.Sort = Convert.ToInt32(reader["Sort"]);
                        collection.Add(menu);
                    }
                }
                return collection;
            }
        }

        public void Update(Menu menu)
        {//TODO
            throw new NotImplementedException();
        }

        public void Update(MenuCollection menuCollection)
        {//TODO
            throw new NotImplementedException();
        }

        public void Delete(Role role)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@Role_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = role.ID;               
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

       
        public bool SetRoles(User user, Role role)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@User_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = user.UserID;
                SqlParameter ColumnParam1 = command.Parameters.Add("@Role_ID", System.Data.SqlDbType.Int);
                ColumnParam1.Value = role.ID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                string result = command.ExecuteScalar().ToString();
                if (result.Equals("0"))
                    return false;
                else
                    return true;
            }
        }

        public bool SetRoles(User user, RoleCollection roleCollection)
        {
            bool IsSuccess= false;
            foreach (Role role in roleCollection)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SP_Frank_TEST";

                    SqlParameter ColumnParam = command.Parameters.Add("@User_ID", System.Data.SqlDbType.Int);
                    ColumnParam.Value = user.UserID;
                    SqlParameter ColumnParam1 = command.Parameters.Add("@Role_ID", System.Data.SqlDbType.Int);
                    ColumnParam1.Value = role.ID;
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    connection.Open();
                    string result = command.ExecuteScalar().ToString();
                    if (result.Equals("0"))
                        IsSuccess = false;
                    else
                        IsSuccess = true;
                }
            }
            return IsSuccess;
        }


    }
}
