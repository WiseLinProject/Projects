﻿using Oleit.AS.Service.DataObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace Oleit.AS.Service.DataService
{
    [ServiceContract]
    public interface IMenuAccess
    {
        [OperationContract]
        void Insert(Role role, Menu menu);

        [OperationContract]
        void Insert(Role role, MenuCollection menucollection);

        [OperationContract]
        MenuCollection Query(Role role);

        [OperationContract]
        MenuCollection Query();

        [OperationContract]
        void Update(Menu menu);

        [OperationContract]
        void Update(MenuCollection menuCollection);

        [OperationContract]
        void Delete(Role role);      

        [OperationContract]
        bool SetRoles(User user, Role role);

        [OperationContract]
        bool SetRoles(User user, RoleCollection roleCollection);
    }
}
