﻿using Oleit.AS.Service.DataObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace Oleit.AS.Service.DataService
{
    [ServiceContract]
    public interface ILimitControl
    {
        [OperationContract]
        EntityCollection GetEntities(User user);

        [OperationContract]
        AccountCollection GetAccounts(User user);

        [OperationContract]
        MenuCollection GetMenu(User user);

        [OperationContract]
        bool CheckLimit(User user, int itemID);
    }
}
