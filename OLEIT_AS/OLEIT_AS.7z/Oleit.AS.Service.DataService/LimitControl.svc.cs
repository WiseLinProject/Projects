﻿using Oleit.AS.Service.DataObject;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
namespace Oleit.AS.Service.DataService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "LimitControl" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select LimitControl.svc or LimitControl.svc.cs at the Solution Explorer and start debugging.
    public class LimitControl : ILimitControl
    {
        string connectionString = ConfigurationManager.ConnectionStrings["AccountDataBase"].ConnectionString;

        public EntityCollection GetEntities(User user)
        {
            EntityCollection collection = new EntityCollection();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@User_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = user.UserID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity entity = new Entity();
                        entity.EntityID = Convert.ToInt32(reader["ID"]);
                        entity.EntityName = reader["Name"].ToString();
                        entity.EntityType = (EntityType)Convert.ToInt32(reader["Type"]);
                        entity.Currency.CurrencyID = reader["Currency"].ToString();
                        entity.ExchangeRate = Convert.ToDecimal(reader["Exchange_Rate"]);
                        entity.SumType = (SumType)Convert.ToInt32(reader["SumType"]);
                        collection.Add(entity);
                    }
                }
                return collection;
            } 
        }

        public AccountCollection GetAccounts(User user)
        {
            AccountCollection collection = new AccountCollection();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@User_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = user.UserID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Account account = new Account();
                        account.AccountName = reader["Name"].ToString();
                        account.AccountType = (AccountType)(Convert.ToInt32(reader["Type"]));
                        account.BettingLimit = Convert.ToDecimal(reader["Betting_Limit"]);
                        account.Status = (Status)(Convert.ToInt32(reader["Status"]));                        
                        collection.Add(account);
                    }
                }
                return collection;
            } 
        }

        public MenuCollection GetMenu(User user)
        {
            MenuCollection collection = new MenuCollection();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@User_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = user.UserID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Menu menu = new Menu();
                        menu.ItemID = Convert.ToInt32(reader["Menu_ID"]);
                        menu.Text = reader["Text"].ToString();
                        menu.Path = reader["Path"].ToString();
                        menu.ParentID = Convert.ToInt32(reader["ParentID"]);
                        menu.Sort = Convert.ToInt32(reader["Sort"]);
                        collection.Add(menu);
                    }
                }
                return collection;
            }
        }

        public bool CheckLimit(User user, int itemID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_Frank_TEST";

                SqlParameter ColumnParam = command.Parameters.Add("@User_ID", System.Data.SqlDbType.Int);
                ColumnParam.Value = user.UserID;
                SqlParameter ColumnParam1 = command.Parameters.Add("@ID", System.Data.SqlDbType.Int);
                ColumnParam1.Value = itemID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();

                string Islimit = command.ExecuteScalar().ToString();
                if (Islimit.Equals("0"))
                    return false;
                else
                    return true;
               
            }
        }
    }
}
