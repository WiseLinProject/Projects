﻿using Oleit.AS.Service.DataObject;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Oleit.AS.Service.DataService.WCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MLJRecordAccess" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MLJRecordAccess.svc or MLJRecordAccess.svc.cs at the Solution Explorer and start debugging.
    public class MLJRecordAccess : IMLJRecordAccess
    {
        string connectionString = ConfigurationManager.ConnectionStrings["AccountDataBase"].ConnectionString;
       
        public int Insert(MLJRecord record)
        {
            int _batchid = -1;
            using (SqlConnection connection_record = new SqlConnection(connectionString))
            {
                connection_record.Open();
                SqlTransaction tr = connection_record.BeginTransaction();
                try
                {
                    using (SqlCommand _command = new SqlCommand("SP_INS_Table", connection_record))
                    {
                        _command.Transaction = tr;
                        SqlParameter _param = _command.Parameters.Add("@value1", System.Data.SqlDbType.VarChar);
                        _param.Value = "MLJ_Journal_Batch";
                        SqlParameter _param2 = _command.Parameters.Add("@value2", System.Data.SqlDbType.VarChar);
                        _param2.Value = "2,3";
                        StringBuilder _content = new StringBuilder();
                        _content.AppendFormat("{0}{1}", record.Period.ID, ",");                     
                        _content.AppendFormat("{0}", (int)record.RecordStatus);
                        SqlParameter _param3 = _command.Parameters.Add("@value3", System.Data.SqlDbType.VarChar);
                        _param3.Value = _content.ToString();
                        _command.CommandType = System.Data.CommandType.StoredProcedure;
                        SqlDataReader reader = _command.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                _batchid = Convert.ToInt32(reader["identity_ID"].ToString());
                            }
                        }
                        reader.Close();
                    }                  
                    if (!_batchid.Equals(-1))
                    {
                        foreach (MLJJournal journal in record.MLJJournalCollection)
                        {
                            using (SqlCommand _jcommand = new SqlCommand("SP_INS_Table", connection_record))
                            {                                
                                _jcommand.Transaction = tr;
                                SqlParameter _jparam1 = _jcommand.Parameters.Add("@value1", System.Data.SqlDbType.VarChar);
                                _jparam1.Value = "MLJ_Journal";
                                SqlParameter _jparam2 = _jcommand.Parameters.Add("@value2", System.Data.SqlDbType.VarChar);
                                _jparam2.Value = "2,3,4,5,6,7,8,9,10,11,12,13";
                                StringBuilder _jcontent = new StringBuilder();
                                _jcontent.AppendFormat("{0}{1}", _batchid, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.EntityID, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.Mon, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.Tue, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.Wed, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.Thu, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.Fri, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.Sat, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.Sun, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.BaseCurrency, ",");
                                _jcontent.AppendFormat("{0}{1}", journal.ExchangeRate, ",");
                                _jcontent.AppendFormat("{0}", journal.EntryUser.UserID);
                                SqlParameter _jparam3 = _jcommand.Parameters.Add("@value3", System.Data.SqlDbType.VarChar);
                                _jparam3.Value = _jcontent.ToString();
                                _jcommand.CommandType = System.Data.CommandType.StoredProcedure;                           
                                _jcommand.ExecuteNonQuery();
                            }

                        }
                    }
                    tr.Commit();

                }
                catch (Exception)
                {
                    tr.Rollback();
                    throw;
                }
            }

            return _batchid;
        }
       
        public MLJRecordCollection Query(int MLJRecordID)
        {
            throw new NotImplementedException();
        }

        public MLJJournalCollection Query(int PeriodID, string EntityName)
        {
            throw new NotImplementedException();
        }

        public MLJRecordCollection Query(RecordStatus status)
        {
            throw new NotImplementedException();
        }

        public MLJJournalCollection QueryJournal(int MLJRecordID)
        {
            MLJJournalCollection collection = new MLJJournalCollection();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_SEL_Table";
                SqlParameter _param = command.Parameters.Add("@value1", System.Data.SqlDbType.VarChar);
                _param.Value = "MLJ_Journal";
                SqlParameter _param2 = command.Parameters.Add("@value2", System.Data.SqlDbType.VarChar);
                _param2.Value = "2";
                SqlParameter _param3 = command.Parameters.Add("@value3", System.Data.SqlDbType.VarChar);
                _param3.Value = MLJRecordID;
                SqlParameter _param4 = command.Parameters.Add("@order_by1", System.Data.SqlDbType.VarChar);
                _param4.Value = "1";
                SqlParameter _param5 = command.Parameters.Add("@order_by2", System.Data.SqlDbType.TinyInt);
                _param5.Value = 0;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        MLJJournal journal = new MLJJournal();
                        journal.SequenceNo = Convert.ToInt32(reader["ID"]);
                        journal.MLJRecordID = Convert.ToInt32(reader["Batch_ID"]);
                        journal.EntityID = Convert.ToInt32(reader["Entity_ID"]);
                        UserAccess usera = new UserAccess();
                        journal.EntryUser = new UserCollection(usera.Query(Convert.ToInt32(reader["Entry_User"])))[0];
                        journal.BaseCurrency = reader["Base_Currency"].ToString();                                       
                        journal.ExchangeRate = Convert.ToDecimal(reader["Exchange_Rate"]);
                        journal.Mon = Convert.ToDecimal(reader["Mon"].ToString());
                        journal.Tue = Convert.ToDecimal(reader["Tue"].ToString());
                        journal.Wed = Convert.ToDecimal(reader["Wed"].ToString());
                        journal.Thu = Convert.ToDecimal(reader["Thu"].ToString());
                        journal.Fri = Convert.ToDecimal(reader["Fri"].ToString());
                        journal.Sat = Convert.ToDecimal(reader["Sat"].ToString());
                        journal.Sun = Convert.ToDecimal(reader["Sun"].ToString());
                        collection.Add(journal);
                    }
                }
                reader.Close();
                return collection;
            }
        }

        public void Update(MLJRecord record)
        {
            throw new NotImplementedException();
        }

        public void UpdateJournal(MLJJournal journal)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_UPD_Table";
                SqlParameter _param = command.Parameters.Add("@value1", System.Data.SqlDbType.VarChar);
                _param.Value = "MLJ_Journal";
                SqlParameter _param2 = command.Parameters.Add("@value2", System.Data.SqlDbType.VarChar);
                _param2.Value = "4,5,6,7,8,9,10";
                StringBuilder _content = new StringBuilder();
                _content.AppendFormat("{0}{1}", journal.Mon, ",");
                _content.AppendFormat("{0}{1}", journal.Tue, ",");
                _content.AppendFormat("{0}{1}", journal.Wed, ",");
                _content.AppendFormat("{0}{1}", journal.Thu, ",");
                _content.AppendFormat("{0}{1}", journal.Fri, ",");
                _content.AppendFormat("{0}{1}", journal.Sat, ",");
                _content.AppendFormat("{0}", journal.Sun);               
                SqlParameter _param3 = command.Parameters.Add("@value3", System.Data.SqlDbType.VarChar);
                _param3.Value = _content.ToString();
                SqlParameter _param4 = command.Parameters.Add("@value4", System.Data.SqlDbType.VarChar);
                _param4.Value = "1";
                SqlParameter _param5 = command.Parameters.Add("@value5", System.Data.SqlDbType.VarChar);
                _param5.Value = journal.SequenceNo;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void UpdateJournal(MLJJournalCollection journalCollection)
        {
            throw new NotImplementedException();
        }

        public void ChangeStatus(int MLJRecordID, RecordStatus status,int userID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_UPD_Table";
                SqlParameter _param = command.Parameters.Add("@value1", System.Data.SqlDbType.VarChar);
                _param.Value = "MLJ_Journal_Batch";
                SqlParameter _param2 = command.Parameters.Add("@value2", System.Data.SqlDbType.VarChar);
                _param2.Value = "3,4";
                StringBuilder _content = new StringBuilder();
                _content.AppendFormat("{0}{1}", (int)status, ",");
                _content.AppendFormat("{0}", userID);
                SqlParameter _param3 = command.Parameters.Add("@value3", System.Data.SqlDbType.VarChar);
                _param3.Value = _content.ToString();
                SqlParameter _param4 = command.Parameters.Add("@value4", System.Data.SqlDbType.VarChar);
                _param4.Value = "1";
                SqlParameter _param5 = command.Parameters.Add("@value5", System.Data.SqlDbType.VarChar);
                _param5.Value = MLJRecordID;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void CheckAndAdd(int periodid,int userid)
        {            
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = "SP_SEL_Table";
                SqlParameter _param = command.Parameters.Add("@value1", System.Data.SqlDbType.VarChar);
                _param.Value = "MLJ_Journal_Batch";
                SqlParameter _param2 = command.Parameters.Add("@value2", System.Data.SqlDbType.VarChar);
                _param2.Value = "1";
                SqlParameter _param3 = command.Parameters.Add("@value3", System.Data.SqlDbType.VarChar);
                _param3.Value = periodid;
                SqlParameter _param4 = command.Parameters.Add("@order_by1", System.Data.SqlDbType.VarChar);
                _param4.Value = "1";
                SqlParameter _param5 = command.Parameters.Add("@order_by2", System.Data.SqlDbType.TinyInt);
                _param5.Value = 0;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                
                if (!reader.HasRows)
                {
                   //First Get Peoperty MLJ EntityID
                    
                    MLJRecord _MLJ = new MLJRecord();
                    _MLJ.Period.ID = periodid;
                    _MLJ.RecordStatus = RecordStatus.Normal;

                    int _MLJEntityID = Convert.ToInt32(new PropertyCollection(new PropertyAccess().Query("MLJEntity"))[0].PropertyValue);
                    EntityCollection _accountcollection = new EntityCollection(new EntityAccess().QuerySubAccount(_MLJEntityID));
                    MLJJournalCollection _jcollection = new MLJJournalCollection();                    
                    foreach (Entity _entity in _accountcollection)
                    {
                        MLJJournal _journal = new MLJJournal();
                        _journal.EntityID = _entity.EntityID;
                        _journal.BaseCurrency = _entity.Currency.CurrencyID;
                        _journal.ExchangeRate = _entity.ExchangeRate;
                        _journal.Mon = 0; _journal.Tue = 0; _journal.Wed = 0; _journal.Thu = 0; _journal.Fri = 0; _journal.Sat = 0; _journal.Sun = 0;
                        _journal.EntryUser.UserID = userid;
                        _jcollection.Add(_journal);
                    }
                    Insert(_MLJ);                        
                }
                reader.Close();
            }
        }

    }
}
