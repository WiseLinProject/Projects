﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Accounting_System.TallyServiceReference;
using Oleit.AS.Service.DataObject;
using Newtonsoft.Json;

namespace Accounting_System
{
    public partial class TallyAjax : System.Web.UI.Page
    {
        public string JsonTallyTreeString = "";
        public int UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["UserId"] = 34;
            UserId = (int)Session["UserId"];
            int _entityId;
            int.TryParse(Request["entityId"], out _entityId);
            if(Request["type"]=="load")
            Response.Write(loadTallyTree(_entityId));
            else
            {
                confirmTally( _entityId);
            }
            

        }
        
        private string loadTallyTree(int _entityId)
        {
            var _tsr = new TallyServiceClient();
            var _loadEntity = _tsr.LoadEntity(_entityId);
            EntityCollection _tallyTree = new EntityCollection(_loadEntity.Item1);//SerializeToJson
            string _tallyStr = JsonEntityFunc.LoadEntityTree(_tallyTree,_loadEntity.Item2);
            return _tallyStr;
        }

        private void confirmTally(int _entityId)
        {
            var _tsr = new TallyServiceClient();
            var _wsJson = JsonConvert.SerializeObject(_tsr.Confirm(UserId, _entityId));
            Response.Write(_wsJson);

        }
    }
}