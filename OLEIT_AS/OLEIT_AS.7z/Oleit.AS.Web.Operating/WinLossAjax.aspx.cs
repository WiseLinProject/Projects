﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using Newtonsoft.Json;
using Accounting_System.CalculateServiceReference;
using Accounting_System.EntityServiceReference;
using Accounting_System.PeriodServiceReference;
using Accounting_System.PropertiesServiceReference;
using Accounting_System.DataEntryServiceReference;
using Accounting_System.SettleServiceReference;
using Oleit.AS.Service.DataObject;
using System.Text;

namespace Accounting_System
{
    public partial class WinLossAjax : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string _jsonWinLoss = Request["json"];
            string _type = Request["type"];
            string _idStr = Request["idStr"];
            
            int _entityId;
            int.TryParse(Request["entityId"], out _entityId);

            int _recordId;
            int.TryParse(Request["recordid"], out _recordId);

            if (_type.Equals("Add", StringComparison.OrdinalIgnoreCase))
            {
                string[] _idStrAry = _idStr.Split(',');
                checkAdd(_entityId, _idStrAry);
            }
            else if (_type.Equals("AutoCalculate", StringComparison.OrdinalIgnoreCase))
                autoCalculate(_jsonWinLoss);
            else if (_type.Equals("Save", StringComparison.OrdinalIgnoreCase))
                save(_jsonWinLoss);
            else
            {
                confirm(_recordId, _jsonWinLoss);
            }
        }

        private void autoCalculate(string _jsonWinLoss)
        {
            var _jsonJW = JsonConvert.DeserializeObject<JsonWinLoss>(_jsonWinLoss);
            var _cs = new CalculateServiceClient();
            var _user = new User();
            var _jc = from j in _jsonJW.journal
                      select new Journal
                                 {
                                     EntityID = j.EntityId,
                                     BaseCurrency = j.Currency,
                                     ExchangeRate = j.ER,
                                     SGDAmount = j.Amount,
                                     BaseAmount = j.BaseAmount,
                                     EntryUser = _user
                                 };
            var _allocateId = _jsonJW.journal.Select(x => x.AllocateId).ToArray();
            var _journal = _cs.AutoJournal(_jc.ToArray());
            var _sb = new StringBuilder();
            _sb.Append("<tr id=\"trTitle\"><td>Entity Type</td><td>Entity</td><td>Currency</td><td>Rate</td><td>Base Amount</td><td>Amount</td><td></td></tr>");
            foreach (var journal in _journal)
            {
                string _input =
                    "<input type=\"text\" style=\"width:80px\" value=\""+journal.SGDAmount+"\" id=\"txt"+journal.EntityID+"\" onkeyup=\"autoSum('"+journal.EntityID+"');\" onkeydown=\"return checkNum(event)\";>";
                var _esr = new EntityServiceClient();
                var _eneity = _esr.LoadEntity2(journal.EntityID)[0];
                var _entityName = string.Format("{0}({1})", _eneity.EntityName, mainEntityNameFunc(_eneity.EntityID));
                var _entityType = _eneity.EntityType == EntityType.PAndL ? "PnL" : _eneity.EntityType == EntityType.Cash ? "Cash" : "Exp";
                const string _deleteIcon = "<span title=\"delete\" onclick=\"deleteEntityCheck(this);\" class=\"ui-button-icon-primary ui-icon ui-icon-closethick \"></span>";
                _sb.AppendFormat("<tr id='WL{0}' class='{1}'><td>{1}</td><td>{2}</td><td id='currency{0}'>{3}</td><td id='er{0}'>{4}</td><td id='baseAmount{0}'>{5}</td><td id='amount{0}'>{6}</td><td>{7}</td></tr>", journal.EntityID, _entityType, _entityName, journal.BaseCurrency, journal.ExchangeRate, journal.BaseAmount, _input, _deleteIcon);
            }
            decimal subTotal = _journal.Sum(x => x.SGDAmount);
            _sb.Append("<tr><td colspan='6' style=\"border:0px\"><hr/></td></tr>");
            _sb.AppendFormat("<tr><td style=\"border:0px\" colspan=\"4\"></td><td style=\"border:0px;font-weight: bold;color: black\">SubTotal</td><td id='subTotal' style=\"text-align: right;border:0px;font-weight: bold;color: black\">{0}</td></tr>",subTotal);
            
            Response.Write(_sb);
        }

        private void checkAdd(int _entityId, string[] _idStrAry)
        {
            var _esr = new EntityServiceClient();
            var _acc = _esr.LoadAccountEntities(_entityId);
            StringBuilder _sb = new StringBuilder();
            const string _deleteIcon = "<span title='delete' onclick='deleteEntityCheck(this);' class='ui-button-icon-primary ui-icon ui-icon-closethick'></span>";
            if (_acc.Any())
            {
                foreach (var entity in _acc)
                {
                    if (_idStrAry.Contains(entity.EntityID.ToString()))
                    {
                        if (_acc.Count() == 1)
                        {
                            _sb.Append("Bad choose! You can't choose repeated.");
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    string _inputBox = string.Format("<input type='text' style='width:80px' id='txt{0}' onkeyup=\"autoSum('{0}');\" onkeydown='return checkNum(event);'/>", entity.EntityID);
                    string entityType = entity.EntityType == EntityType.Cash
                                            ? "Cash"
                                            : entity.EntityType == EntityType.PAndL ? "PnL" : "Exp";
                    _sb.AppendFormat("<tr allocateId='{0}' id='WL{0}' class='{1}'><td>{1}</td><td>{2}</td><td id='currency{0}'>{3}</td><td id='er{0}'>{4}</td><td id='baseAmount{0}'>{5}</td><td id='amount{0}'>{6}</td><td>{7}</td></tr>", entity.EntityID, entityType, entity.EntityName, entity.Currency.CurrencyID, entity.ExchangeRate, 0, _inputBox, _deleteIcon);

                }
                Response.Write(_sb.ToString());
            }
            else
            {
                Response.Write("Fail!");
            }

        }

        private void save(string _jsonWinLoss)
        {
            var _jsonJW = JsonConvert.DeserializeObject<JsonWinLoss>(_jsonWinLoss);
            var _user = new User();
            string _propertyValue = new PropertiesServiceClient().GetPropertyValue2("ClosedPeriod")[0].PropertyValue;
            int  periodId = new PeriodServiceClient().DateOfPeriod(_propertyValue)[0].ID;
            var _desr = new DataEntryServiceClient();
            var _journal = from j in _jsonJW.journal
                           select new Journal
                                      {
                                          EntityID = j.EntityId,
                                          BaseCurrency = j.Currency,
                                          BaseAmount = j.BaseAmount,
                                          SGDAmount = j.Amount,
                                          ExchangeRate = j.ER,
                                          EntryUser = _user
                                      };
            var _record = new Record
                              {
                                  Type = RecordType.WinAndLoss,
                                  RecordStatus = RecordStatus.Normal,
                                  Period = new Period
                                               {
                                                   ID=periodId
                                               }

                              };
            Response.Write(_desr.InsertRecord(_record,_journal.ToArray())); // You don't return RecordId how do I get the new RecordId?? for Yang
        }

        private void confirm(int _recordId,string _jsonWinLoss)
        {
            var _jsonJW = JsonConvert.DeserializeObject<JsonWinLoss>(_jsonWinLoss);
            var _user = new User ();
            string _propertyValue = new PropertiesServiceClient().GetPropertyValue2("ClosedPeriod")[0].PropertyValue;
            int periodId = new PeriodServiceClient().DateOfPeriod(_propertyValue)[0].ID;
            var _weeklySummary = from j in _jsonJW.journal
                                 select new WeeklySummary
                                            {
                                                Period = new Period {ID = periodId},
                                                Entity = new Entity {EntityID = j.EntityId},
                                                BaseCurrency = j.Currency,
                                                ExchangeRate = j.ER,
                                                BaseWinAndLoss = j.BaseAmount,
                                                SGDWinAndLoss = j.Amount,
                                                Status = WeeklySummaryStatus.Confirm,
                                                ConfirmUser = _user
                                            };
            var _ssr = new SettleServiceClient();
            _ssr.WinLossConfirm(_weeklySummary.ToArray(),_recordId);
        }

        public class JsonWinLoss
        {
            public IEnumerable<JsonJournal> journal { get; set; }
            public decimal? subTotal { get; set; }
            
        }
        public class JsonJournal
        {
            public int AllocateId { get; set; }
            public int EntityId { get; set; }
            public string Currency { get; set; }
            public decimal ER { get; set; }
            public decimal BaseAmount { get; set; }
            public decimal Amount { get; set; }
        }

        private  string mainEntityNameFunc(int _entityId)
        {
            var _esr = new EntityServiceClient();
            Entity _tmpEntity = _esr.LoadEntity2(_entityId)[0];
            while (_tmpEntity.ParentID!=0)
            {
                _tmpEntity = _esr.LoadEntity2(_tmpEntity.ParentID)[0];
            }
            return _tmpEntity.EntityName;
        }

        
    }
}