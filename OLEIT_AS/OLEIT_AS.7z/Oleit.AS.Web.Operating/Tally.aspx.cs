﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Accounting_System.EntityServiceReference;
using Oleit.AS.Service.DataObject;

namespace Accounting_System
{
    public partial class Tally : System.Web.UI.Page
    {
        public string JsonEntityTreeString = "";
        public int UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //JsonTallyTreeString = LoadTallyTree();
                JsonEntityTreeString = JsonEntityFunc.LoadEntityTree();
                loadMainEntity();
            }
            Session["UserId"] = 34;
            UserId = (int)Session["UserId"];
            
            

        }

        private void loadMainEntity()
        {
            var _esr = new EntityServiceClient();
            var _entityCollection =  _esr.LoadEntity1();
            var _mainEntityCollection = from mec in _entityCollection.Where(x => x.ParentID == 0).OrderByDescending(x=>x.EntityID)
                                        select new
                                                   {
                                                       Text= mec.EntityName,
                                                       Value = mec.EntityID
                                                   };
            ddlMainEntity.DataSource = _mainEntityCollection.ToList();
            ddlMainEntity.DataTextField = "Text";
            ddlMainEntity.DataValueField = "Value";
            ddlMainEntity.DataBind();
        }
    }
}