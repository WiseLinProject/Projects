﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Accounting_System.EntityServiceReference;
using Accounting_System.DataEntryServiceReference;
using Accounting_System.PeriodServiceReference;
using Oleit.AS.Service.DataObject;
using System.Data;

namespace Accounting_System
{
    public partial class TransactionEntry : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {//ToDo
            tx_FromEntity.Attributes.Add("readonly","true");
            tx_ToEntity.Attributes.Add("readonly", "true");
            tx_Amount.Attributes.Add("OnKeyPress", "txtKeyNumber();");
            Session["Userid"] = 33;
            if (!IsPostBack)
            {
                Session["IsAdd"] = false;
                //tree
                List<MyObject> list = new List<MyObject>();
                EntityServiceClient _intclient = new EntityServiceClient();
                foreach (Entity entity in new EntityCollection(_intclient.LoadAll()))
                {
                    list.Add(new MyObject() { Id = entity.EntityID, Name = entity.EntityName, ParentId = entity.ParentID });
                }
                BindTree(list, null);
                PeriodServiceClient _pclient = new PeriodServiceClient();
                Period _period = new PeriodCollection(_pclient.GetClosedPeriod())[0];
                GetData(_period);

            }
        }

        private void GetData(Period _period)
        {
            DataEntryServiceClient _client = new DataEntryServiceClient();
            TransactionCollection _collection = new TransactionCollection();
            if(!_period.ID.Equals(0))
                _collection = new TransactionCollection(_client.LoadTransactionByPeriodID(_period.ID));
            else
                _collection = new TransactionCollection(_client.LoadTransaction());
            DataTable dt = new DataTable();
            dt.Columns.Add("id"); dt.Columns.Add("FromEntity"); dt.Columns.Add("ToEntity"); dt.Columns.Add("FromEntityid");
            dt.Columns.Add("ToEntityid"); dt.Columns.Add("Amount"); dt.Columns.Add("Notice"); dt.Columns.Add("NoticeTime");
            dt.Columns.Add("Pay"); dt.Columns.Add("Confirm"); dt.Columns.Add("ConfirmTime"); dt.Columns.Add("Updater");
            dt.Columns.Add("Creator");
            foreach (Transaction _tran in _collection)
            {
                DataRow newRow = dt.NewRow();
                newRow["id"] = _tran.ID;
                newRow["FromEntity"] = _tran.FromEntity.EntityName;
                newRow["ToEntity"] = _tran.ToEntity.EntityName;
                newRow["FromEntityid"] = _tran.FromEntity.EntityID;
                newRow["ToEntityid"] = _tran.ToEntity.EntityID;
                newRow["Amount"] = _tran.Amount;
                newRow["Notice"] = _tran.NoticeUser.UserName;
                if (!_tran.NoticeTime.ToShortDateString().Equals("0001/1/1"))
                    newRow["NoticeTime"] = _tran.NoticeTime;

                newRow["Pay"] = _tran.IsPay;
                newRow["Confirm"] = _tran.ConfirmUser.UserName;
                if (!_tran.ConfirmTime.ToShortDateString().Equals("0001/1/1"))
                newRow["ConfirmTime"] = _tran.ConfirmTime;
                newRow["Updater"] = _tran.Updater.UserName;
                newRow["Creator"] = _tran.Creator.UserName;
                dt.Rows.Add(newRow);
            }
            gv_Transaction.DataSource = dt;
            gv_Transaction.DataBind();
            up_gvGrid.Update();
        }

        private void BindTree(IEnumerable<MyObject> list, TreeNode parentNode)
        {
            var nodes = list.Where(x => parentNode == null ? x.ParentId == 0 : x.ParentId == int.Parse(parentNode.Value));
            foreach (var node in nodes)
            {
                TreeNode newNode = new TreeNode(node.Name, node.Id.ToString());
                if (parentNode == null)
                {
                    Tree_FromEntity.Nodes.Add(newNode);                    
                }
                else
                {
                    parentNode.ChildNodes.Add(newNode);
                }
                BindTree(list, newNode);
            }
            foreach (var node in nodes)
            {
                TreeNode newNode = new TreeNode(node.Name, node.Id.ToString());
                if (parentNode == null)
                {                   
                    Tree_ToEntity.Nodes.Add(newNode);
                }
                else
                {
                    parentNode.ChildNodes.Add(newNode);
                }
                BindTree(list, newNode);
            }
        }

        public class MyObject
        {
            public int Id;
            public int ParentId;
            public string Name;
            
        }
        protected void btn_showFrom_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
        }
        
        protected void btn_showTo_Click(object sender, EventArgs e)
        {
            Panel2.Visible = true;
        }

        protected void Tree_FromEntity_SelectedNodeChanged(object sender, EventArgs e)
        {
            tx_FromEntity.Text = Tree_FromEntity.SelectedNode.Text;
            lb_FromEntityID.Text = Tree_FromEntity.SelectedNode.Value;
            Panel1.Visible = false;
        }

        protected void Tree_ToEntity_SelectedNodeChanged(object sender, EventArgs e)
        {
            tx_ToEntity.Text = Tree_ToEntity.SelectedNode.Text;
            lb_ToEntityID.Text = Tree_ToEntity.SelectedNode.Value;
            Panel2.Visible = false;
        }
       
        protected void gv_Transaction_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            int id = Convert.ToInt32(gv_Transaction.DataKeys[row.RowIndex].Values[0]);
            string _FromEntityID =gv_Transaction.DataKeys[row.RowIndex].Values[1].ToString();
            string _ToEntityID = gv_Transaction.DataKeys[row.RowIndex].Values[2].ToString();
          //  string _FromEntityID = gv_Transaction.DataKeys[row.RowIndex].Values[1].ToString();
           // string _FromEntityID = gv_Transaction.DataKeys[row.RowIndex].Values[1].ToString();
            using (DataEntryServiceClient _client = new DataEntryServiceClient())
            {
                PeriodServiceClient _pclient = new PeriodServiceClient();
                Period _period = new PeriodCollection(_pclient.GetClosedPeriod())[0];
                if (e.CommandName.Equals("Btn_Notice"))
                {
                    _client.SetNotices(id, Convert.ToInt32(Session["Userid"]));
                    GetData(_period);
                   
                }
                else if (e.CommandName.Equals("Btn_Confirm"))
                {
                    _client.SetConfirm(id, Convert.ToInt32(Session["Userid"]), _period.ID);
                    GetData(_period);
                    
                }
                else if (e.CommandName.Equals("Btn_Edit"))
                {
                    Session["IsAdd"] = false;                    
                    tx_FromEntity.Text = gv_Transaction.Rows[row.RowIndex].Cells[0].Text ;
                    tx_ToEntity.Text = gv_Transaction.Rows[row.RowIndex].Cells[1].Text;
                    tx_Amount.Text = gv_Transaction.Rows[row.RowIndex].Cells[2].Text;
                    lb_FromEntityID.Text = _FromEntityID;
                    lb_ToEntityID.Text = _ToEntityID;
                    btn_Confirm.Text = "Edit";
                    lb_ID.Text = id.ToString();
                    up_Edit.Update();
                    mp1.Show();

                }
            }
        }

        protected void gv_Transaction_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells[5].Text.Equals("Y"))
                {
                    Button _btn_Edit = (Button)e.Row.FindControl("Btn_Edit");
                    Button _btn_Notice = (Button)e.Row.FindControl("Btn_Notice");
                    Button _btn_Confirm = (Button)e.Row.FindControl("Btn_Confirm");
                    _btn_Edit.Visible = false;
                    _btn_Notice.Visible = false;
                    _btn_Confirm.Visible = false;
                }
                if (e.Row.Cells[3].Text.Equals("&nbsp;"))
                {
                    Button _btn_Confirm = (Button)e.Row.FindControl("Btn_Confirm");
                    _btn_Confirm.Visible = false;
                }
            }
        }
        
        protected void btn_Add_Click(object sender, EventArgs e)
        {            
            tx_FromEntity.Text = "";
            tx_ToEntity.Text = "";
            tx_Amount.Text = "";
            Session["IsAdd"] = true;
            up_Edit.Update();
            mp1.Show();            
        }

        protected void btn_Confirm_Click(object sender, EventArgs e)
        {
            if (tx_FromEntity.Text.Equals("") || tx_ToEntity.Text.Equals(""))
            {
                Alert(" You have to select [ From cloumn ] or [ To Entity ] . ");
                return;
            }
            if (tx_Amount.Text.Equals(""))
            {
                Alert(" You have to key in Amount . ");
                return;
            }
            string regex = "^[0-9]{0,5}$|^[0-9]{0,5}\\.[0-9]{0,2}$ ";
            System.Text.RegularExpressions.RegexOptions options = ((System.Text.RegularExpressions.RegexOptions.IgnorePatternWhitespace | System.Text.RegularExpressions.RegexOptions.Multiline)
            | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex(regex, options);
            if (!reg.IsMatch(tx_Amount.Text))
            {
                Alert(" Please check Amount column . ");
                return;
            }
            using (DataEntryServiceClient _client = new DataEntryServiceClient())
            {
                PeriodServiceClient _pclient = new PeriodServiceClient();
                Period _period = new PeriodCollection(_pclient.GetClosedPeriod())[0];

                int _FromEntityID = Convert.ToInt32(lb_FromEntityID.Text);
                int _ToEntityID = Convert.ToInt32(lb_ToEntityID.Text);
                decimal _Amount = Convert.ToDecimal(tx_Amount.Text);
                if ((bool)Session["IsAdd"])
                {
                    Transaction _tran = new Transaction();
                    _tran.Period.ID = _period.ID;
                    _tran.IsPay = IsPay.N;
                    _tran.Creator.UserID = Convert.ToInt32(Session["Userid"]);
                    _tran.Amount = _Amount;
                    _tran.FromEntity.EntityID = _FromEntityID;
                    _tran.ToEntity.EntityID = _ToEntityID;
                    _client.InsertTransaction(_tran);
                    mp1.Hide();
                    GetData(_period);
                  
                }
                else
                {
                    _client.Updatetransaction(Convert.ToInt32(lb_ID.Text), Convert.ToInt32(Session["Userid"]),_FromEntityID,_ToEntityID,_Amount);
                    mp1.Hide();
                    GetData(_period);
                   
                }
            }
        }
        private void Alert(string message)
        {
            string script = string.Format("alert('{0}');", HttpUtility.HtmlEncode(message.Replace("\n", "\\n")));
            JavaScrpit("window_aler", script);
        }
        private void JavaScrpit(string name, string script)
        {
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), name, script, true);
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            mp1.Hide(); 
            up_Edit.Update();            
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            Period _period = new Period();
            if(tx_Period.Text.Equals(""))
                GetData(_period);
            else
            {
                PeriodServiceClient _pclient = new PeriodServiceClient();
                try
                {
                    _period = new PeriodCollection(_pclient.DateOfPeriod(tx_Period.Text))[0];
                    GetData(_period);
                }
                catch (Exception)
                {
                    throw;                
                }
                
            }
        }
    }
}