﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Accounting_System.InternalUserServiceReference;
using Oleit.AS.Service.DataObject;

namespace Accounting_System
{
    public partial class UserMgmt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            loadGridView();//initial gridview
            Session["UserId"] = "Frank";
            Session["UserId2"] = "Trevor";
        }

        /// <summary>
        /// Initial AD gridview and QS gridview
        /// </summary>
        private void loadGridView()
        {
            var _iusr = new InternalUserServiceClient();
            _iusr.QueryADuser();
            gvAD.DataSource = _iusr.QueryADuser().ToList();
            gvAD.DataBind();
            gvQS.DataSource = _iusr.QueryAlluser().ToList();
            gvQS.DataBind();
        }

        /// <summary>
        /// Insert AD user to Query System user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            var _iusc = new InternalUserServiceClient();
            var _adString = hfADString.Value.Split(new[]{","},StringSplitOptions.RemoveEmptyEntries);
            var _adUserAry = from q in _adString
                       select new User
                                  {
                                      UserName = q
                                  };
            _iusc.NewUserCollection(_adUserAry.ToArray());
            loadGridView();
            Page.ClientScript.RegisterStartupScript(GetType(), "Success string", "Alert('Insert Success !');", true);
        }

        protected void gvQS_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                CheckBox cb = (CheckBox) e.Row.FindControl("cbQS");
                if (e.Row.Cells[4].Text == "1")
                {
                    e.Row.Cells[4].Text = "true";
                    cb.Checked = true;
                }
                else
                    e.Row.Cells[4].Text = "false";
            }
        }

        /// <summary>
        /// Update users in Query System 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            var _iusc = new InternalUserServiceClient();
            var _updateQS = from GridViewRow row in gvQS.Rows
                            let _cb = (CheckBox)row.Cells[0].FindControl("cbQS")
                            let _cbVal = _cb.Checked == true ? 1 : 0
                            select new User
                            {
                                UserID = int.Parse(row.Cells[1].Text),
                                UserName = row.Cells[2].Text,
                                Enable = _cbVal
                            };
            _iusc.Disable(_updateQS.ToArray());
            loadGridView();
            Page.ClientScript.RegisterStartupScript(GetType(), "Success string", "Alert('Update Success !');", true);
        }
    }
}