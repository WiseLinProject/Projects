﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Accounting_System.PeriodServiceReference;
using Accounting_System.PropertiesServiceReference;
using Accounting_System.SettleServiceReference;


namespace Accounting_System
{
    public partial class Settle : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                loadPeriod();
            }
        }

        private void loadPeriod()
        {
            var _psr = new PeriodServiceClient();
           lblCurrentPeriod.Text= _psr.GetClosedPeriod()[0].PeriodNo;
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            var _ssc = new SettleServiceClient();
            _ssc.CloseEntry();
            loadPeriod();

        }

        protected void btnReverse_Click(object sender, EventArgs e)
        {
            var _ssc = new SettleServiceClient();
            _ssc.ReverseClosing();
            loadPeriod();
        }
    }
}