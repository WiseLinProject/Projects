﻿function previousPic() {
    var cls = $("#imgPrototype").attr("class");
    var num = cls.substring(cls.indexOf("_") + 1, cls.length);
    var type = $("#imgPrototype").attr("type");
    var max = $("#imgPrototype").attr("max");
    var min = $("#imgPrototype").attr("min");
    if (num == "2") {
        $("#previousBtn").css("display", "none");
    } else if (num == max) {
        $("#nextBtn").css("display", "block");
    } else {
        $("#previousBtn").css("display", "block");
        $("#nextBtn").css("display", "block");
    }
    $("#imgPrototype").attr("class", "img_" + (parseInt(num) - 1)).attr("src", "img/" + type + (parseInt(num) - 1) + ".jpg");
}

function nextPic() {
    var cls = $("#imgPrototype").attr("class");
    var num = cls.substring(cls.indexOf("_") + 1, cls.length);
    var type = $("#imgPrototype").attr("type");
    var max = $("#imgPrototype").attr("max");
    var min = $("#imgPrototype").attr("min");
    max = parseInt(max) - 1;
    if (num == "1") {
        $("#previousBtn").css("display", "block");
    }
    else if (num == max) {
        $("#nextBtn").css("display", "none");
    } else {
        $("#previousBtn").css("display", "block");
        $("#nextBtn").css("display", "block");
    }
    $("#imgPrototype").attr("class", "img_" + (parseInt(num) + 1)).attr("src", "img/" + type + (parseInt(num) + 1) + ".jpg");
}