﻿var queryC = new QueryC();
var queryR = new QueryR();
var queryG = new QueryG();

function QueryC() {
    this.Filter = [];
}
function QueryR() {
    this.Filter = [];
}
function QueryG() {
    this.Filter = [];
}

var useAdvPrice = false;
var groupLink;
$(function () {
    //ViewReport Link
    $("#report").accordion({header:"h3", collapsible: true, heightStyle: "content" });
    $("#mainTab, #groupDialogC, #groupDialogR, #groupDialogG").tabs();
    OpenReport();
    $("#bettingInfo").dialog({
        autoOpen: false,
        modal: true,
        width: '300px'
    });
    $("#groupDialogC, #groupDialogR, #groupDialogG").dialog({
        autoOpen: false,
        modal: true,
        width: '400px'
    });
    $('#LeagueNameInputC, #LeagueNameInputR, #LeagueNameInputG').watermark("Enter League name here");
    $("#showGroupC, #showGroupR, #showGroupG").click(function () {
        var showId = $(this).attr("id");
        var DialogId = "#groupDialog" + showId.substring(showId.length - 1, showId.length);
        $(DialogId).dialog({
            position: { my: "left top", at: "left bottom", of: "#" + showId },
            autoOpen: true
        });
    });
    var Leagues = [];
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "AjaxJson.aspx",
        dataType: "json",
        async: true,
        success: function (data) {
            Leagues = data;
            $("#LeagueNameInputC, #LeagueNameInputR, #LeagueNameInputG").autocomplete({
                autoFocus: true,
                source: Leagues,
                select: function (event, ui) {
                    var canInsert = true;
                    var thisId = $(this).attr("id");
                    var CRG = thisId.substring(thisId.length - 1, thisId.length);
                    $("li[id^='LeagueId" + CRG + "_']").each(function () {
                        var id = $(this).attr("id");
                        if (id.substring(id.indexOf("_") + 1, id.length) == ui.item.LeagueId) {
                            canInsert = false;
                            return;
                        }
                    });
                    if (canInsert == true) {
                        var removeTag = "<a href='#' title=\"remove\" onclick='RemoveFilter(this)'><span class='removeA'> x</span></a>";
                        var liTag = "<li id='LeagueId" + CRG + "_" + ui.item.LeagueId + "' value='" + ui.item.label + "'><span class='post-tag' >" + ui.item.label + "</span>" + removeTag + "</li>";
                        $("#LeagueList" + CRG).append($(liTag));
                    }
                    else
                        alert("\"" + ui.item.label + "\" is already been chosen!");
                    $(this).val("");//$("#LeagueNameInputC").val() ="";
                    return false;//let input do not show your entering words
                }
            });
        }
    });

    $("#spreadC a, #spreadR a, #spreadG a").click(function () {
        var parentId = $(this).parent().attr("id");
        var CRG = parentId.substring(parentId.length - 1, parentId.length);
        removeliTag(CRG);
        if (CRG == "C")
            queryC.SpreadOrLeague = new Array();
        else if (CRG == "R")
            queryR.SpreadOrLeague = new Array();
        else 
            queryG.SpreadOrLeague = new Array();
        
        if (CRG == "C") {
            var groupC = new groupObj();
            groupC.Spread_or_League = 0;
            groupC.Spread_or_League_Value = $(this).attr("value");
            queryC.SpreadOrLeague.push(groupC);
        }
        else if(CRG == "R"){
            var groupR = new groupObj();
            groupR.Spread_or_League = 0;
            groupR.Spread_or_League_Value = $(this).attr("value");
            queryR.SpreadOrLeague.push(groupR);
        }
        else {
            var groupG = new groupObj();
            groupG.Spread_or_League = 0;
            groupG.Spread_or_League_Value = $(this).attr("value");
            queryG.SpreadOrLeague.push(groupG);
        }

        var liTag = "<li id='grp" + $(this).attr("value") + "' name='grp' CRG='" + CRG + "'><span class='post-tag'>Group " + $(this).attr("value") + "</span></li>";
        $("#SLselectlist" + CRG).append($(liTag));
        $("#clearGroup" + CRG).show();
        $("#groupDialog" + CRG).dialog("close");
    });
    function groupObj(Spread_or_League, Spread_or_League_Value) {
        this.Spread_or_League = Spread_or_League,
        this.Spread_or_League_Value = Spread_or_League_Value;
    }
    $("#leagueC>input[type='button'], #leagueR>input[type='button'], #leagueG>input[type='button']").click(function () {
        var thisId = $(this).parent().attr("id");
        var CRG = thisId.substring(thisId.length - 1, thisId.length);
        if (CRG == "C")
            queryC.SpreadOrLeague = new Array();
        else if (CRG == "R")
            queryR.SpreadOrLeague = new Array();
        else
            queryG.SpreadOrLeague = new Array();
        removeliTag(CRG);
        $("li[id^='LeagueId" + CRG + "']").each(function () {
            var Lid = $(this).attr("id");
            var id = Lid.substring(Lid.indexOf("_") + 1, Lid.length);
            var leagueid = $("#" + Lid).attr("id");
            var liTag = "<li id='lea" + id + "' name='lea' CRG='" + CRG + "'><span class='post-tag'>" + $("#" + Lid).attr("value") + "</span></li>";
            $("#SLselectlist" + CRG).append($(liTag));
            if (CRG == "C") {
                var groupC = new groupObj();
                groupC.Spread_or_League = 1;
                groupC.Spread_or_League_Value = leagueid.substring(leagueid.indexOf("_") + 1, leagueid.length);
                queryC.SpreadOrLeague.push(groupC);
            }
            else if (CRG == "R") {
                var groupR = new groupObj();
                groupR.Spread_or_League = 1;
                groupR.Spread_or_League_Value = leagueid.substring(leagueid.indexOf("_") + 1, leagueid.length);
                queryR.SpreadOrLeague.push(groupR);
            } else {
                var groupG = new groupObj();
                groupG.Spread_or_League = 1;
                groupG.Spread_or_League_Value = leagueid.substring(leagueid.indexOf("_") + 1, leagueid.length);
                queryG.SpreadOrLeague.push(groupG);
            }
        });
        $("#clearGroup" + CRG).show();
        $("#groupDialog" + CRG).dialog("close");
    });
    
    $("#clearGroupC, #clearGroupR, #clearGroupG").click(function () {
        var cls = $(this).attr("id");
        var CRG = cls.substring(cls.length - 1, cls.length);
        if (CRG == "C")
            queryC.SpreadOrLeague = new Array();
        else if (CRG == "R")
            queryR.SpreadOrLeague = new Array();
        else
            queryG.SpreadOrLeague = new Array();
        $("#clearGroup" + CRG).hide();
        removeliTag(CRG);
    });
    
    $("#ClosingFilterAdd, #RunningFilterAdd, #GDFilterAdd").click(function () {
        var id = $(this).attr("id");
        var CRG = id.substring(0, 1);//use the initial letter like "C"、"R"、"G"
        var canInsert = true;
        var alertStr = "";
        $("#OddsFilterTb" + CRG + " input").each(function () {
            if (!$(this).val()) {
                alertStr = "Input error!";
                canInsert = false;
                return false;
            }
        });
        if (canInsert) {
            var list = $("#OddsFilterList" + CRG + " li");
            var cf = new ClosingFilter($("#Maker" + CRG).val(), $("#FilterMode" + CRG).val(), $("#Value1" + CRG).val(), $("#Value2" + CRG).val(), $("#Value3" + CRG).val(), $("#FilterChoice" + CRG).val());
            for (var i = 0; i < list.length; i++) {
                var item = $(list[i]);
                if (item.attr("FilterMode") == cf.FilterMode
                    && item.attr("Value1") == cf.Value1
                    && item.attr("Value2") == cf.Value2
                    && item.attr("Value3") == cf.Value3
                    && item.attr("Choice") == cf.Choice) {
                    canInsert = false;
                    alertStr = "Filter already exists!";
                    break;
                }
            }
        }
        if (canInsert) {
            var text = $("#FilterMode" + CRG + " :selected").text() + "=" + cf.Value1 + ";　price:" + cf.Value2 + " ~ " + cf.Value3 + "; " + $("#FilterChoice" + CRG + " :selected").text();
            var removeTag = "<a href='#' title=\"remove\" onclick='RemoveFilter(this)'><span class='removeA'> x</span></a>";
            var li = $("<li ><span class='post-tag' id=''>" + text + "</span>" + removeTag + "</li>");
            li.attr("FilterMode", cf.FilterMode).attr("Value1", cf.Value1).attr("Value2", cf.Value2).attr("Value3", cf.Value3).attr("Choice", cf.Choice);
            $("#OddsFilterList" + CRG).append(li);
        }
        else
            alert(alertStr);
    });
    $("input[type='text']").each(function () {
        var id = $(this).attr("id");
        if (id != "LeagueNameInputC" && id != "LeagueNameInputR" && id != "LeagueNameInputG" && id.indexOf("QNameInput") == -1) {
            if (id == "Value1C" || id == "Value1R" || id == "Value1G" || id == "ClosingChoicevalue" || id == "TotalMargins" || id == "Market" || id == "GDMarket") {
                $(this).keydown(function (event) {
                    return checkValueMinus(event);
                });
            }
            else {
                $(this).keydown(function (event) {
                    return checkValue(event);
                });
            }
        }
    });
    

    $("#ClosingRecDate_min, #ClosingRecDate_max, #RunningRecDate_min, #RunningRecDate_max, #GDRecDate_min, #GDRecDate_max").datepicker({
        dateFormat: 'yy/mm/dd',
        defaultDate: new Date(2010, 05, 01),
        changeMonth: true,
        changeYear: true,
        minDate: new Date(2010, 6 - 1, 1),
        maxDate: new Date(2012, 12 - 1, 31)

    }).watermark("Click here to Choose").css("width", "120px");

    //ViewReport accordion
    $("#report").accordion({
        change: function () {
            OpenReport();
        }
    });
    $("#refillPrice").click(function() {
        if (useAdvPrice) {
            $("#advPrice").html("");
            startGenPriceFilter();
        }
    });
    $("#GDRecDate_max, #GDMinute2").tooltip({
        position: {
            my: "center bottom-20",
            at: "center top",
            using: function (position, feedback) {
                $(this).css(position);
                $("<div>")
                    .addClass("arrow")
                    .addClass(feedback.vertical)
                    .addClass(feedback.horizontal)
                    .appendTo(this);
            }
        }
    });
    
});

function NameRecord(obj) {
    var parentId = $(obj).parent().attr('id');
    var QS_ID = parentId.substring(parentId.indexOf("Report") + 6, parentId.length);
    var NewName = $("#" + parentId).find("input[name='QNameInput']").val();
    $.ajax({
        type: "POST",
        url: "accodionAjax.aspx",
        data: { Q: QS_ID, QS_Name: NewName,type:2 },
        success: function () {
            $("#QS_Name" + QS_ID).text(NewName);
        }
    });
}

function viewReport() {
    $("#bettingInfo").dialog("close");
    $("#mainTab").tabs('select', 3);
    OpenReport();
}

function OpenReport() {
    var activeId = $("#report").find('.ui-state-active').attr('id');
    if (activeId) {
        var QS_ID = activeId.substring(activeId.indexOf("ID") + 2, activeId.length);
        if ($("#QSTable_" + QS_ID).html() == "")
            $("#QSTable_" + QS_ID).load("accodionAjax.aspx?Q=" + QS_ID + "&bettingType=" + $("#QSTable_" + QS_ID).attr("class")+"&type=1");
    }
}

function resultClick(obj) {
    $("#resultDialog").empty();
    $("#resultDialog").append($("<iframe width='740' height='550'></iframe>"));
    var link = $(obj);
    var title = link.parent().prev().html();//<span class="ui-button-icon-primary ui-icon ui-icon-closethick"></span>
    title = title.replace("<span class=\"ui-accordion-header-icon ui-icon ui-icon-triangle-1-s\"></span>", "").replace("<div style=\"float: right\">", "").replace("<a onclick=\"deleteTest();\" class=\"ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only ui-dialog-titlebar-close\" role=\"button\" aria-disabled=\"false\" title=\"Delete\">", "").replace("<span class=\"ui-button-icon-primary ui-icon ui-icon-closethick\"></span>", "").replace("<span class=\"ui-button-text\"></span>", "").replace("</a>", "").replace("</div>","");
    var type = link.attr("type");
    var id = link.attr("id");
    var QS_ID = id.substring(id.indexOf("ID") + 2, id.length);
    var target;
    if (type == "Closing") 
        target = "ClosingReports.aspx?Q=" + QS_ID;
    else if (type == "Running")
        target = "RunningReports.aspx?Q=" + QS_ID;
    else
        target = "GDReports.aspx?Q=" + QS_ID;

    $("#resultDialog iframe").attr("src", target);
    $("#resultDialog").dialog({ width: "auto", height: "auto", title: title, modal: true });
    $("#resultDialog").find(".ui-accordion-header-icon").remove();
}

function removeliTag(CRG) {
    $("#SLselectlist" + CRG + ">li").each(function () {
        $(this).remove();
    });
}
//add allowing the minus symbol input 
function checkValueMinus(event) {
    if (!((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 110 || event.keyCode == 190 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 116 || event.keyCode == 123 || event.keyCode == 122 || event.keyCode == 189 || event.keyCode == 109 || event.keyCode == 9))
        return false;
    return true;
}

//allow 0~9, backspace, decimal point, delete, Left Arrow, Right Arrow, F5, F12, F13
function checkValue(event) {
    if (!((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 110 || event.keyCode == 190 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 116 || event.keyCode == 123 || event.keyCode == 122 || event.keyCode == 9))
        return false;
    return true;
}

function RemoveFilter(obj) {
    $(obj).parent().fadeOut(function () {
        $(this).remove();
    });
}
//chec Price Function
function checkPrice(MinutesInputs) {
    var maxPrice;
    var minPrice;
    var checkOk = true;
    MinutesInputs.each(function () {
        if ($(this).val() == "") {
            alert("Please enter Price \"Min\" and \"Max\" first !");
            $(this).focus();
            checkOk = false;
            return false;
        }
        if ($(this).attr("id").indexOf("min") != -1)
            minPrice = $(this).val();
        else
            maxPrice = $(this).val();
    });
    if (minPrice > maxPrice) {
        alert("Price \"Min\" can\'t be more than Price \"Max\" !");
        checkOk = false;
    }
    if (checkOk == false)
        return false;
    else
        return true;
}

//check Minutes Function
function checkMinutes(CRG) {
    var maxMinute;
    var minMinute;
    var checkOk = true;
    if (CRG == "R") {
        $("input[id^='Minute']").each(function() {
            if ($(this).val() == "") {
                alert("Please enter Minute \"From\" and \"To\" first !");
                $(this).focus();
                checkOk = false;
                return false;
            }
            if ($(this).attr("id").indexOf("1") != -1)
                minMinute = $(this).val();
            else
                maxMinute = $(this).val();
        });
    } else {//checkGD
        $("input[id^='GDMinute']").each(function () {
            if ($(this).val() == "") {
                alert("Please enter Minute \"From\" and \"To\" first !");
                $(this).focus();
                checkOk = false;
                return false;
            }
            if ($(this).attr("id").indexOf("1") != -1)
                minMinute = $(this).val();
            else
                maxMinute = $(this).val();
        });
        if ($("#GDChoiceMode").val() < 3 && maxMinute > 45) {
            checkOk = false;
            $("#GDMinute2").focus();
            alert("Max minute can't be more 45 minutes when you choice Half time.");
        }
    }
    if (minMinute > maxMinute && checkOk == true) {
        alert("Minute \"From\" can\'t be more than Minute \"To\" !");
        checkOk = false;
    }
    if (checkOk == false)
        return false;
    else
        return true;

}
function checkRequired(CRG) {
    var checkOk = true;
    if (CRG == "C") {
        $(".tableS input[id^='Closing']").each(function () {
            if ($(this).val() == "") {
                alert("Please enter \"StarDate\" and \"EndDate\" first !");
                $(this).focus();
                checkOk = false;
                return false;
            }
        });
        if (checkOk == false)
            return false;
        /*
        if ($("#SLselectlist" + CR + ">li").length == 0) {
            alert("Please choose \"Spread/League\" first !");
            return false;
        }*/
        if ($("#ClosingChoicevalue").val() == "") {
            alert("Please enter \"HDP/Goal\" first !");
            $("#ClosingChoicevalue").focus();
            return false;
        }
        if (checkPrice($("input[id^='ClosingPriceValue']")) == false)
            return false;
        return true;
    }
    else if (CRG == "R") {
        $(".tableS input[id^='Running']").each(function () {
            if ($(this).val() == "") {
                alert("Please enter \"StarDate\" and \"EndDate\" first !");
                $(this).focus();
                checkOk = false;
                return false;
            }
        });
        if (checkOk == false)
            return false;
        if (checkMinutes(CRG) == false)
            return false;
        return true;
    }
    else {
        $(".tableS input[id^='GD']").each(function () {
            if ($(this).val() == "") {
                alert("Please enter \"StarDate\" and \"EndDate\" first !");
                $(this).focus();
                checkOk = false;
                return false;
            }
        });
        if (checkOk == false)
            return false;
        if (checkMinutes(CRG) == false)
            return false;
        return true;
    }
}

//DO Closing Bet
function ClosingBet() {
    if (checkRequired("C")) {
        $("#btnCBet").attr("class", "betting").val("Please wait ...").attr("disabled", "disabled");
        $("#btnRBet").attr("class", "betting").attr("disabled", "disabled");
        $("#btnGBet").attr("class", "betting").attr("disabled", "disabled");
        queryC.RecDate_min = $("#ClosingRecDate_min").val();
        queryC.RecDate_max = $("#ClosingRecDate_max").val();
        queryC.Filter = [];
        var list = $("#OddsFilterListC li");
        for (var i = 0; i < list.length; i++) {
            var item = $(list[i]);
            var cf = new ClosingFilter($("#MakerC").val(), item.attr("FilterMode"), item.attr("Value1"), item.attr("Value2"), item.attr("Value3"), item.attr("Choice"));
            queryC.Filter.push(cf);
        }
        queryC.ChoiceMode = $("#ClosingChoiceMode").val();
        queryC.Choicevalue = $("#ClosingChoicevalue").val();
        queryC.Choice = $("#ClosingChoice").val();
        queryC.PriceValue_min = $("#ClosingPriceValue_min").val();
        queryC.PriceValue_max = $("#ClosingPriceValue_max").val();
        BettingAjax(JSON.stringify(queryC),"Closing");
        return true;
    }
    else
        return false;
}

//Betting with ajax
function BettingAjax(jsonStr, bettingType) {
    $("img.nonebetting").attr("class", "onbetting");
    $.ajax({
        type: "POST",
        url: "BettingServer.aspx",
        async:true,
        data: { type: bettingType, json: jsonStr },
        success: function (data) {
            var text;
            if (bettingType == "Closing") {
                text = "Pregame Betting";
                $("#btnCBet").attr("class", "btn").val(text).removeAttr("disabled");
                $("#btnRBet").attr("class", "btn").removeAttr("disabled");
                $("#btnGBet").attr("class", "btn").removeAttr("disabled");
            }
            else if (bettingType == "Running") {
                text = "Running Betting";
                $("#btnRBet").attr("class", "btn").val(text).removeAttr("disabled");
                $("#btnCBet").attr("class", "btn").removeAttr("disabled");
                $("#btnGBet").attr("class", "btn").removeAttr("disabled");
            } else {
                text = "Submit";
                $("#btnGBet").attr("class", "btn").val(text).removeAttr("disabled");
                $("#btnRBet").attr("class", "btn").removeAttr("disabled");
                $("#btnCBet").attr("class", "btn").removeAttr("disabled");
            }
            $("img.onbetting").attr("class", "nonebetting");
            var dataAry = data.split(',');
            if (bettingType != "GD") {
                $("#bettingInfo span").html("Simulation comleted!<br>Please click <a href=\"#\" onclick='viewReport();'>here</a> to view results.");
                $("#bettingInfo").dialog({
                    autoOpen: true
                });
                GenerateQueryRecord(dataAry[0], bettingType, dataAry[1]);
            }
            else {
                $('html, body').scrollTop(0);
                $("#bettingInfo span").html("Goal Distribution comleted!<br>Please click <a href=\"#\" onclick='GDResult(" + dataAry[0] + ");'>here</a> to view results.");
                $("#bettingInfo").dialog({
                    autoOpen: true
                });
                
            }
        }
    });
}

function GDResult(QS_ID) {
    $("#bettingInfo").dialog("close");
    $("#resultScoreView").empty();
    $("#resultScoreView").append($("<iframe width='840' height='550'></iframe>"));
    var target = "ScoreView.aspx?Q=" + QS_ID;
    $("#resultScoreView iframe").attr("src", target);//mainTab
    $("#resultScoreView").dialog({ width: "auto", height: "auto", weight: "auto", title: "Goal Distribution", modal: true});
    $("#resultScoreView").find(".ui-accordion-header-icon").remove();
}

//Do Running Bet
function RunningBet() {
    if (checkRequired("R")) {
        if (!checkRunningPrice())
            return false;
        if (!checkGoalnMarket("R"))
            return false;
        $("#btnRBet").attr("class", "betting").val("Please wait ...").attr("disabled", "disabled");
        $("#btnCBet").attr("class", "betting").attr("disabled", "disabled");
        $("#btnGBet").attr("class", "betting").attr("disabled", "disabled");
        queryR.RecDate_min = $("#RunningRecDate_min").val();
        queryR.RecDate_max = $("#RunningRecDate_max").val();
        queryR.Minute1 = $("#Minute1").val();
        queryR.Minute2 = $("#Minute2").val();
        queryR.ChoiceMode = $("#RunningChoiceMode").val();
        queryR.Choice = $("#RunningChoice").val();
        queryR.TotalGoals = $("#TotalGoals").val();
        queryR.TotalMargins = $("#TotalMargins").val();
        queryR.Market = $("#Market").val();
        queryR.RedCardH = $("#RedCardH").val();
        queryR.RedCardA = $("#RedCardA").val();
        queryR.Filter = [];
        var list = $("#OddsFilterListR li");
        for (var i = 0; i < list.length; i++) {
            var item = $(list[i]);
            var cf = new ClosingFilter($("#MakerR").val(), item.attr("filtermode"), item.attr("Value1"), item.attr("Value2"), item.attr("Value3"), item.attr("Choice"));
            queryR.Filter.push(cf);
        }
        
        BettingAjax(JSON.stringify(queryR), "Running");
        return true;
    }
    else
        return false;
}

function viewScoreView() {
    $("#resultScoreView").empty();
    $("#resultScoreView").append($("<iframe width='740' height='550'></iframe>"));
    //var link = $(obj);
    //var title = link.parent().prev().html();//<span class="ui-button-icon-primary ui-icon ui-icon-closethick"></span>
    //title = title.replace("<span class=\"ui-accordion-header-icon ui-icon ui-icon-triangle-1-s\"></span>", "").replace("<div style=\"float: right\">", "").replace("<a onclick=\"deleteTest();\" class=\"ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only ui-dialog-titlebar-close\" role=\"button\" aria-disabled=\"false\" title=\"Delete\">", "").replace("<span class=\"ui-button-icon-primary ui-icon ui-icon-closethick\"></span>", "").replace("<span class=\"ui-button-text\"></span>", "").replace("</a>", "").replace("</div>", "");
    //var type = link.attr("type");
    //var id = link.attr("id");
    //var QS_ID = id.substring(id.indexOf("ID") + 2, id.length);
    var target = "GDReports.aspx?Q=" + QS_ID;

    $("#resultScoreView iframe").attr("src", target);
    $("#resultScoreView").dialog({ width: "auto", height: "auto", title: title, modal: true });
   // $("#resultScoreView").find(".ui-accordion-header-icon").remove();
}

function GDSubmit() {
    if (checkRequired("G")) {
        if (!checkGoalnMarket("G"))
            return false;
        $("#btnGBet").attr("class", "betting").val("Please wait ...").attr("disabled", "disabled");
        $("#btnRBet").attr("class", "betting").attr("disabled", "disabled");
        $("#btnCBet").attr("class", "betting").attr("disabled", "disabled");
        queryG.RecDate_min = $("#GDRecDate_min").val();
        queryG.RecDate_max = $("#GDRecDate_max").val();
        if (Date.parse(queryG.RecDate_max) - Date.parse(queryG.RecDate_min) > 31536000000) {
            alert("The \"date range\" is over than 1 year so the Goal Distribution will spend more time to query. ");
        }
        queryG.Filter = [];
        var list = $("#OddsFilterListG li");
        for (var i = 0; i < list.length; i++) {
            var item = $(list[i]);
            var cf = new ClosingFilter("", item.attr("FilterMode"), item.attr("Value1"), item.attr("Value2"), item.attr("Value3"), item.attr("Choice"));
            queryG.Filter.push(cf);
        }
        queryG.Minute1 = $("#GDMinute1").val();
        queryG.Minute2 = $("#GDMinute2").val();
        queryG.ChoiceMode = $("#GDChoiceMode").val();
        queryG.Choice = $("#GDChoice").val();
        queryG.TotalGoals = $("#GDTotalGoals").val();
        queryG.TotalMargins = $("#GDTotalMargins").val();
        queryG.Market = $("#GDMarket").val();
        queryG.RedCardH = $("#GDRedCardH").val();
        queryG.RedCardA = $("#GDRedCardA").val();
        BettingAjax(JSON.stringify(queryG), "GD");
        return true;
    }
    else
        return false;
}

function checkGoalnMarket(CRG) {
    var MarketId;
    if (CRG == "R")
        MarketId = "Market";
    else 
        MarketId = "GDMarket";
    if ($("#" + MarketId).val() == "") {
        alert("Please enter \"Market\" value!");
        $("#Market").focus();
        return false;
    }
    return true;
}

///ClosingFilter Class
function ClosingFilter(Maker, FilterMode, Value1, Value2, Value3, Choice) {
    this.Maker = Maker;
    this.FilterMode = FilterMode;
    this.Value1 = Value1;
    this.Value2 = Value2;
    this.Value3 = Value3;
    this.Choice = Choice;
    this.equals = function (other) {
        return Maker == other.Maker && FilterMode == other.FilterMode && Value1 == other.Value1 && Value2 == other.Value2 && Value3 == other.Value3 && Choice == other.Choice;
    };
}
///RunningFilter Class
function RunningFilter(Value1, Value2, Value3, Value4, Value5) {
    this.Value1 = Value1;
    this.Value2 = Value2;
    this.Value3 = Value3;
    this.Value4 = Value4;
    this.Value5 = Value5;
    this.equals = function (other) {
        return Value1 == other.Value1 && Value2 == other.Value2 && Value3 == other.Value3 && Value4 == other.Value4 && Value5 == other.Value5;
    };
}

///Check Running Price Function
function checkRunningPrice() {
    queryR.Price = [];
    var start = $("#Minute1").val();
    var end = parseInt($("#Minute2").val()) + 1;
    var price = 0;
    var rate = 0;
    var checkPriceOk = true;
    if ($("#txtPrice").val() != "")
        price = parseFloat($("#txtPrice").val());
    if ($("#txtRate").val())
        rate = $("#txtRate").val();
    var groupPrice;//price filter
    if ($("#AdvancePrice").text() == "Enable Advance Setting") {
        for (i = start; i < end; i++) {
            var f = i;
            if (f > 45) {
                f -= 45;
            }
            f = 45 - f;
            groupPrice = new RunningFilter(price, rate, i, parseFloat(price) + rate * f, ((parseFloat(price) + rate * f) * (1 + parseFloat($("#priceRange").val()) / 100)).toFixed(3));
            queryR.Price.push(groupPrice);
        }
    }
    else {
        $("input[name='AdvancePriceListMin']").each(function () {
            if ($(this).val() == "") {
                checkPriceOk = false;
                alert("Please enter your advance price !");
                if ($(this).val() == "")
                    $(this).focus();
                return false;
            }
            else {
                groupPrice = new RunningFilter(price, rate, start, $(this).val(), $(this).parent().find("input[name = 'AdvancePriceListMax']").val());
                queryR.Price.push(groupPrice);
            }
            start++;
        });
    }
    if (!checkPriceOk)
        return false;
    else
        return true;
}

///Generate Price Function
function GeneratePrice(obj) {
    useAdvPrice = !useAdvPrice;
    var CRG = "R";
    if (checkMinutes(CRG)) {
        if (useAdvPrice) {
            $(obj).text("Disable Advance Setting");
            startGenPriceFilter();
        } else {
            $(obj).text("Enable Advance Setting");
            $("#advPrice").html("");
        }
    }
    else
        useAdvPrice = !useAdvPrice;
}

//open the price filter and fill the price to input box
function  startGenPriceFilter() {
    var start = $("#Minute1").val();
    var end = parseInt($("#Minute2").val()) + 1;
    var price = 0;
    if ($("#txtPrice").val() != "")
        price = parseFloat($("#txtPrice").val());

    var rate = $("#txtRate").val();
    var priceList = [];
    for (var i = start; i < end; i++) {
        if (i == start) {
            var header;
            if ($("#priceRange").val() != "0" && $("#priceRange").val() != "")
                header = $("<div>Minute　PriceMin　PriceMax</div>");
            else 
                header = $("<div>Minute　PriceMin</div>");
            priceList.push(header);
        }
        var f = i;
        if (f > 45) {
            f -= 45;
        }
        f = 45 - f;
        var div;
        if ($("#priceRange").val() != "0" && $("#priceRange").val() != "") {
            div = $("<div>　" + i + ":　　<input type='text' name='AdvancePriceListMin' class='number' /> ～ <input type='text' name='AdvancePriceListMax' class='number' /></div>");
            div.find("input[name='AdvancePriceListMax']").val(((parseFloat(price) + (rate * f)) * (1 + parseFloat($("#priceRange").val()) / 100)).toFixed(3));
        } else {
            div = $("<div>　" + i + ":　　<input type='text' name='AdvancePriceListMin' class='number' /></div>");
        }
        div.find("input[name='AdvancePriceListMin']").val(parseFloat(price) + (rate * f));
        priceList.push(div);
    }
    $("#advPrice").prepend(priceList);
}

function getDateTimeNow() {
    var DateTime = new Date();
    var yy = DateTime.getFullYear();
    var MM = DateTime.getMonth() + 1;
    var dd = DateTime.getDate();
    var HH = DateTime.getHours();
    var mm = DateTime.getMinutes();
    var ss = DateTime.getSeconds();
    return yy + "-" + (MM < 10 ? "0" + MM : MM) + "-" + (dd < 10 ? "0" + dd : dd) + " " + (HH < 10 ? "0" + HH : HH) + ":" + (mm < 10 ? "0" + mm : mm) + ":" + (ss < 10 ? "0" + ss : ss);
}
    
///Generate query record report
function GenerateQueryRecord(QS_ID, bettingType, BettingTime) {    
    var deletionIcon = "<div style='float: right'><a id='deleteReport_" + QS_ID + "' onclick='deleteReport(this,3);' class='ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only ui-dialog-titlebar-close' role='button' aria-disabled='false' title='Delete'><span class='ui-button-icon-primary ui-icon ui-icon-closethick'></span><span class='ui-button-text'></span></a></div>";
    var h3 = $("<h3 id='QS_ID" + QS_ID + "'><span id='QS_Name"+QS_ID+"' class='QS_Name'></span>" + BettingTime + " - <span class='" + bettingType + "H3'>" + bettingType + "</span>"+deletionIcon+"</h3>");
    var tableStr;
    $.ajax({
        type: "POST",
        url: "accodionAjax.aspx",
        async: false,
        data: { bettingType: bettingType, Q: QS_ID,type :1 },
        success: function (data) {
            tableStr= data;
        }
    });
    var reNameInput = "<input type='text' id='QNameInput'" + QS_ID + " name='QNameInput' />";
    var reNameButton = "<input type='button' onclick='NameRecord(this);' class='btn' value='Rename' />";    
    var div = $("<div id='Report"+QS_ID+"'><a href='#' id='VR_ID" + QS_ID + "' type='" + bettingType + "' class='viewReport' onclick='resultClick(this);'>View Report</a>" + reNameInput + reNameButton + tableStr + "</div>");
    div.insertAfter($("#prepend"));
    h3.insertAfter($("#prepend"));    
    $("#report").accordion("destroy").accordion({header:"h3", collapsible: true, heightStyle: "content" });
    OpenReport();
}

//delete jQuery UI Accordion
function deleteReport(obj, type) {
    if (confirm("Do you really want to delete?")) {
        var QS_ID;
        if (type == 3) {
            var Id = $(obj).attr("id");
            QS_ID = Id.substring(Id.indexOf("deleteReport_") + 13, Id.length);
        } else
            QS_ID = -1;
        $.ajax({
            type: "POST",
            async: false,
            url: "accodionAjax.aspx",
            data: {Q:QS_ID,type:type},
            success: function (data) {
                if (data == 1) {
                    if (type == 3) {                        
                        $("h3#QS_ID" + QS_ID).fadeOut(function () {
                            $(this).remove();
                        });
                        var activeId = $("#report").find('.ui-state-active').attr('id');
                        if (!activeId) {
                            $("div#Report" + QS_ID).css('display', 'block');
                            $("div#Report" + QS_ID).fadeOut(function () {
                                $(this).remove();
                            });
                        }
                    }
                    else {
                        $("h3[id^='QS_ID'], div[id^='Report']").each(function () {
                            $(this).fadeOut(function () {
                                $(this).remove();
                            });
                        });
                    }
                    alert("Success!");                    
                }
                else
                    alert("Failed");
            }
        });
    }
}