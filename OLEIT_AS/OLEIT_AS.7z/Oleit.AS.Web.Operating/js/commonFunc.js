﻿function Alert(alertStr) {
    alert(alertStr);
}

//allow 0~9, backspace, decimal point, delete, Left Arrow, Right Arrow, F5, F12, F13, Home, End
function checkNum(event) {
    if (!((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 110 || event.keyCode == 190 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 116 || event.keyCode == 123 || event.keyCode == 122 || event.keyCode == 189 || event.keyCode == 109 || event.keyCode == 9 || event.keyCode == 35 || event.keyCode == 36))
        return false;
    return true;
}


function deleteEntity(obj) {
    $(obj).fadeOut(function () {
        $(this).parent().parent().remove();
    });
}