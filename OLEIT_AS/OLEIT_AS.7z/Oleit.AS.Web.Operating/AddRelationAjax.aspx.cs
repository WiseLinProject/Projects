﻿using System;
using System.Linq;
using Oleit.AS.Service.DataObject;
using Accounting_System.EntityServiceReference;
using System.Text;

namespace Accounting_System
{
    public partial class AddRelationAjax : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string _relation = Request["Relation"];
            string _target = Request["Target"];
            decimal _value;
            decimal.TryParse(Request["Value"],out _value);
            string _entityClass = Request["EntityClass"];
            int _entityId = int.Parse(Request["EntityId"]);

            int _targetId;
            int.TryParse(Request["TargetId"], out _targetId);

            int _relationValue;
            int.TryParse(Request["RelationValue"],out _relationValue);

            string _relationLoad = Request["RelationLoad"];
            if(_relationLoad!=null)
            {
                loadRelation(_entityId);
            }
            else
            {
                addRelation(_entityClass,_relation, _relationValue, _target, _value, _entityId, _targetId);
            }

        }
        private void addRelation(string _entityClass,string _relation, int _relationValue, string _target, decimal _value, int _entityId, int _targetId)
        {
            var _esc = new EntityServiceClient();
            //var _relationCollection = 
            if (_esc.GetRelateEntity(_entityId).Any(x => x.Description == RelationDescription.Allocate) && _relationValue==1)
                Response.Write("There is already a Allocate Relation!");
            else if (_relationValue == 5 && _entityClass.IndexOf("MainEntity", StringComparison.OrdinalIgnoreCase) == -1)
            {//when other entities chose the PnLSum
                Response.Write("PAndLSum type only can be chosen by P&L Main Entity!");
            }
            else if (_entityClass.IndexOf("MainEntity", StringComparison.OrdinalIgnoreCase)!=-1 && _relationValue<5)
            {//when PnL Main entity didn't choose the PnLSum type
                Response.Write("P&L Main Entity only can choose the PnLSum type!");
            }
            else
            {
                var _newR = _relationValue == 1 ? RelationDescription.Allocate : _relationValue == 2 ? RelationDescription.Position : _relationValue == 3 ? RelationDescription.Commission : _relationValue == 4 ? RelationDescription.FollowBet : RelationDescription.PAndLSum;
                #region "Relation Value"
                /*

                switch (_relationValue)
                {
                    case 1:
                        {
                            _newRD = RelationDescription.Allocate;
                            break;
                        }
                    case 2:
                        {
                            _newRD = RelationDescription.Commission;
                            break;
                        }
                    case 3:
                        {
                            _newRD = RelationDescription.Position;
                            break;
                        }
                    case 4:
                        {
                            _newRD = RelationDescription.FollowBet;
                            break;
                        }
                }

                */
               #endregion
                var _newRelation = new Relation
                                       {
                                           Numeric = _value,
                                           Description = _newR,
                                           /*
                                           Entity = new Entity {EntityID = _entityId},
                                           TargetEntity = new Entity {EntityID = _targetId},*/
                                       };
                if (_entityId != _targetId)
                {
                    try
                    {
                        _esc.NewRelation(_entityId, _targetId,_newRelation);
                        Response.Write("Success!");
                    }
                    catch (Exception)
                    {
                        Response.Write("Failed!");
                    }
                }
                else
                {
                    Response.Write("You can't relate to yourself!");
                }
            }
        }
        private void loadRelation(int _entityId)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<tr><td colspan=\"3\">Entity Relation</td></tr>");
            sb.Append("<tr id=\"trRelationTitle\"><td class=\"relationTitle\">Relation</td><td class=\"relationTitle\">To</td><td class=\"relationTitle\">Value</td></tr>");
            EntityServiceClient _esc = new EntityServiceClient();
            var test = _esc.RelationEntity(_entityId);
            foreach (var r in test)
            {
                var _relationType = r.Description == RelationDescription.Allocate ? "Allocate" : r.Description == RelationDescription.Commission ? "Commission" : r.Description == RelationDescription.Position ? "Position" : r.Description == RelationDescription.FollowBet ? "FollowBet" : "PnLSum";
                sb.AppendFormat("<tr><td>{0}</td><td>{1}({2})</td><td>{3}</td></tr>", _relationType, r.TargetEntity.EntityName, r.Entity.EntityName, r.Numeric);
            }
            Response.Write(sb.ToString());
        }
    }
}